/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	function webpackJsonpCallback(data) {
/******/ 		var chunkIds = data[0];
/******/ 		var moreModules = data[1];
/******/ 		var executeModules = data[2];
/******/
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [];
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(Object.prototype.hasOwnProperty.call(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(data);
/******/
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/
/******/ 		// add entry modules from loaded chunk to deferred list
/******/ 		deferredModules.push.apply(deferredModules, executeModules || []);
/******/
/******/ 		// run deferred modules when all chunks ready
/******/ 		return checkDeferredModules();
/******/ 	};
/******/ 	function checkDeferredModules() {
/******/ 		var result;
/******/ 		for(var i = 0; i < deferredModules.length; i++) {
/******/ 			var deferredModule = deferredModules[i];
/******/ 			var fulfilled = true;
/******/ 			for(var j = 1; j < deferredModule.length; j++) {
/******/ 				var depId = deferredModule[j];
/******/ 				if(installedChunks[depId] !== 0) fulfilled = false;
/******/ 			}
/******/ 			if(fulfilled) {
/******/ 				deferredModules.splice(i--, 1);
/******/ 				result = __webpack_require__(__webpack_require__.s = deferredModule[0]);
/******/ 			}
/******/ 		}
/******/
/******/ 		return result;
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded CSS chunks
/******/ 	var installedCssChunks = {
/******/ 		"app": 0
/******/ 	}
/******/
/******/ 	// object to store loaded and loading chunks
/******/ 	// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 	// Promise = chunk loading, 0 = chunk loaded
/******/ 	var installedChunks = {
/******/ 		"app": 0
/******/ 	};
/******/
/******/ 	var deferredModules = [];
/******/
/******/ 	// script path function
/******/ 	function jsonpScriptSrc(chunkId) {
/******/ 		return __webpack_require__.p + "js/" + ({"about":"about","cmLoader":"cmLoader","contribute":"contribute","results":"results"}[chunkId]||chunkId) + ".js.gz"
/******/ 	}
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/ 	// This file contains only the entry chunk.
/******/ 	// The chunk loading function for additional chunks
/******/ 	__webpack_require__.e = function requireEnsure(chunkId) {
/******/ 		var promises = [];
/******/
/******/
/******/ 		// mini-css-extract-plugin CSS loading
/******/ 		var cssChunks = {"about":1,"cmLoader":1,"results":1};
/******/ 		if(installedCssChunks[chunkId]) promises.push(installedCssChunks[chunkId]);
/******/ 		else if(installedCssChunks[chunkId] !== 0 && cssChunks[chunkId]) {
/******/ 			promises.push(installedCssChunks[chunkId] = new Promise(function(resolve, reject) {
/******/ 				var href = "css/" + ({"about":"about","cmLoader":"cmLoader","contribute":"contribute","results":"results"}[chunkId]||chunkId) + ".css.gz";
/******/ 				var fullhref = __webpack_require__.p + href;
/******/ 				var existingLinkTags = document.getElementsByTagName("link");
/******/ 				for(var i = 0; i < existingLinkTags.length; i++) {
/******/ 					var tag = existingLinkTags[i];
/******/ 					var dataHref = tag.getAttribute("data-href") || tag.getAttribute("href");
/******/ 					if(tag.rel === "stylesheet" && (dataHref === href || dataHref === fullhref)) return resolve();
/******/ 				}
/******/ 				var existingStyleTags = document.getElementsByTagName("style");
/******/ 				for(var i = 0; i < existingStyleTags.length; i++) {
/******/ 					var tag = existingStyleTags[i];
/******/ 					var dataHref = tag.getAttribute("data-href");
/******/ 					if(dataHref === href || dataHref === fullhref) return resolve();
/******/ 				}
/******/ 				var linkTag = document.createElement("link");
/******/ 				linkTag.rel = "stylesheet";
/******/ 				linkTag.type = "text/css";
/******/ 				linkTag.onload = resolve;
/******/ 				linkTag.onerror = function(event) {
/******/ 					var request = event && event.target && event.target.src || fullhref;
/******/ 					var err = new Error("Loading CSS chunk " + chunkId + " failed.\n(" + request + ")");
/******/ 					err.code = "CSS_CHUNK_LOAD_FAILED";
/******/ 					err.request = request;
/******/ 					delete installedCssChunks[chunkId]
/******/ 					linkTag.parentNode.removeChild(linkTag)
/******/ 					reject(err);
/******/ 				};
/******/ 				linkTag.href = fullhref;
/******/
/******/ 				var head = document.getElementsByTagName("head")[0];
/******/ 				head.appendChild(linkTag);
/******/ 			}).then(function() {
/******/ 				installedCssChunks[chunkId] = 0;
/******/ 			}));
/******/ 		}
/******/
/******/ 		// JSONP chunk loading for javascript
/******/
/******/ 		var installedChunkData = installedChunks[chunkId];
/******/ 		if(installedChunkData !== 0) { // 0 means "already installed".
/******/
/******/ 			// a Promise means "currently loading".
/******/ 			if(installedChunkData) {
/******/ 				promises.push(installedChunkData[2]);
/******/ 			} else {
/******/ 				// setup Promise in chunk cache
/******/ 				var promise = new Promise(function(resolve, reject) {
/******/ 					installedChunkData = installedChunks[chunkId] = [resolve, reject];
/******/ 				});
/******/ 				promises.push(installedChunkData[2] = promise);
/******/
/******/ 				// start chunk loading
/******/ 				var script = document.createElement('script');
/******/ 				var onScriptComplete;
/******/
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.src = jsonpScriptSrc(chunkId);
/******/
/******/ 				// create error before stack unwound to get useful stacktrace later
/******/ 				var error = new Error();
/******/ 				onScriptComplete = function (event) {
/******/ 					// avoid mem leaks in IE.
/******/ 					script.onerror = script.onload = null;
/******/ 					clearTimeout(timeout);
/******/ 					var chunk = installedChunks[chunkId];
/******/ 					if(chunk !== 0) {
/******/ 						if(chunk) {
/******/ 							var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 							var realSrc = event && event.target && event.target.src;
/******/ 							error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 							error.name = 'ChunkLoadError';
/******/ 							error.type = errorType;
/******/ 							error.request = realSrc;
/******/ 							chunk[1](error);
/******/ 						}
/******/ 						installedChunks[chunkId] = undefined;
/******/ 					}
/******/ 				};
/******/ 				var timeout = setTimeout(function(){
/******/ 					onScriptComplete({ type: 'timeout', target: script });
/******/ 				}, 120000);
/******/ 				script.onerror = script.onload = onScriptComplete;
/******/ 				document.head.appendChild(script);
/******/ 			}
/******/ 		}
/******/ 		return Promise.all(promises);
/******/ 	};
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "https://coderushcdn.ddns.net/";
/******/
/******/ 	// on error function for async loading
/******/ 	__webpack_require__.oe = function(err) { console.error(err); throw err; };
/******/
/******/ 	var jsonpArray = window["webpackJsonp"] = window["webpackJsonp"] || [];
/******/ 	var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
/******/ 	jsonpArray.push = webpackJsonpCallback;
/******/ 	jsonpArray = jsonpArray.slice();
/******/ 	for(var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
/******/ 	var parentJsonpFunction = oldJsonpFunction;
/******/
/******/
/******/ 	// add entry module to deferred list
/******/ 	deferredModules.push([0,"chunk-vendors"]);
/******/ 	// run deferred modules when ready
/******/ 	return checkDeferredModules();
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("56d7");


/***/ }),

/***/ "07fb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CodeEditor_vue_vue_type_style_index_0_id_a9580c94_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("ad14");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CodeEditor_vue_vue_type_style_index_0_id_a9580c94_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CodeEditor_vue_vue_type_style_index_0_id_a9580c94_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CodeEditor_vue_vue_type_style_index_0_id_a9580c94_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ 1:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ "2e4a":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "2f3e":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "3243":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "3743":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "3a6a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SettingsMenu_vue_vue_type_style_index_0_id_7a2cc102_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("8c3e");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SettingsMenu_vue_vue_type_style_index_0_id_7a2cc102_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SettingsMenu_vue_vue_type_style_index_0_id_7a2cc102_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SettingsMenu_vue_vue_type_style_index_0_id_7a2cc102_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "3fc2":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "56d7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.runtime.esm.js
var vue_runtime_esm = __webpack_require__("2b0e");

// EXTERNAL MODULE: ./node_modules/vue-socket.io-extended/dist/vue-socket.io-ext.esm.js
var vue_socket_io_ext_esm = __webpack_require__("f87c");

// EXTERNAL MODULE: ./node_modules/socket.io-client/lib/index.js
var lib = __webpack_require__("8055");
var lib_default = /*#__PURE__*/__webpack_require__.n(lib);

// EXTERNAL MODULE: ./node_modules/@fortawesome/fontawesome-svg-core/index.es.js
var index_es = __webpack_require__("ecee");

// EXTERNAL MODULE: ./node_modules/@fortawesome/vue-fontawesome/index.es.js
var vue_fontawesome_index_es = __webpack_require__("ad3d");

// EXTERNAL MODULE: ./node_modules/@fortawesome/free-solid-svg-icons/index.es.js
var free_solid_svg_icons_index_es = __webpack_require__("c074");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"4cb10de2-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/App.vue?vue&type=template&id=698c7402&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{ref:"app",attrs:{"id":"app"}},[(!_vm.tooSmall)?[_c('aside',{ref:"navLeft",staticClass:"nav-left",class:{thin: _vm.isPlaying, wide: _vm.room.connected }},[_c('NavBar',{class:[{thin: _vm.isPlaying }],on:{"start":function($event){return _vm.$children[1].run()}}})],1),_c('main',[_c('keep-alive',{attrs:{"exclude":['Run', 'Results']}},[_c('router-view')],1)],1)]:_c('SmallScreen')],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/App.vue?vue&type=template&id=698c7402&

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"4cb10de2-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/NavBar.vue?vue&type=template&id=7f714fa1&scoped=true&
var NavBarvue_type_template_id_7f714fa1_scoped_true_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('nav',[_c('button',{staticClass:"title",on:{"click":_vm.mainPage}},[_vm._v(" CodeRush "),_c('span',{staticClass:"beta"},[_vm._v("BETA")])]),_c('div',{staticClass:"links",class:{'room-connected': _vm.room.connected}},[_c('button',{staticClass:"link",on:{"click":function($event){return _vm.mainPage(true)}}},[_c('fa',{class:{flip: _vm.$route.path === '/run'},attrs:{"icon":['fas', 'play']}}),_c('span',{staticClass:"btn-text"},[_vm._v(" Start ")])],1),_c('div',{staticClass:"line"}),_c('button',{staticClass:"link language",on:{"click":function($event){return _vm.$store.commit('USER_LANGUAGE')}}},[_c('fa',{directives:[{name:"show",rawName:"v-show",value:(_vm.userLanguage),expression:"userLanguage"}],attrs:{"icon":['fas', 'globe-americas']}}),_c('fa',{directives:[{name:"show",rawName:"v-show",value:(!_vm.userLanguage),expression:"!userLanguage"}],attrs:{"icon":['fas', 'globe-europe']}}),_c('span',{staticClass:"btn-text"},[_vm._v(" "+_vm._s(_vm.userLanguage ? 'English Here' : 'Polska wersja')+" ")])],1),_c('div',{staticClass:"line"}),_c('router-link',{staticClass:"link",attrs:{"to":"/about"}},[_c('fa',{attrs:{"icon":['fas', 'info']}}),_c('span',{staticClass:"btn-text"},[_vm._v(" About ")])],1),_c('div',{staticClass:"line"}),_c('router-link',{staticClass:"link",attrs:{"to":"/contribute"}},[_c('fa',{attrs:{"icon":['fas', 'file-code']}}),_c('span',{staticClass:"btn-text"},[_vm._v(" Contribute ")])],1)],1),_c('RoomPanel',{staticClass:"room"}),_c('div',{staticClass:"author"},[_c('span',{staticClass:"author-text"},[_vm._v(" Made with "),_c('fa',{staticClass:"heart",attrs:{"icon":['fas', 'heart']}}),_vm._v(" by "),_c('span',{staticClass:"author-name"},[_vm._v("Łukasz Wielgus")])],1)])],1)}
var NavBarvue_type_template_id_7f714fa1_scoped_true_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/NavBar.vue?vue&type=template&id=7f714fa1&scoped=true&

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"4cb10de2-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/RoomPanel.vue?vue&type=template&id=7610ead2&scoped=true&
var RoomPanelvue_type_template_id_7610ead2_scoped_true_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"room"},[_c('div',{directives:[{name:"show",rawName:"v-show",value:(!_vm.room.connected),expression:"!room.connected"}],staticClass:"roomNotConnected"},[_c('p',{staticClass:"room-text"},[_vm._v(" Play with your friends: ")]),_c('div',{staticClass:"roomName"},[_c('fa',{attrs:{"icon":['fas', 'server']}}),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.roomName),expression:"roomName"}],attrs:{"maxlength":"14","type":"text","placeholder":"Room name"},domProps:{"value":(_vm.roomName)},on:{"input":[function($event){if($event.target.composing){ return; }_vm.roomName=$event.target.value},_vm.resetInfoMsg],"keydown":function($event){if(!$event.type.indexOf('key')&&_vm._k($event.keyCode,"enter",13,$event.key,"Enter")){ return null; }return _vm.handleEnter($event)}}})],1),_c('div',{directives:[{name:"show",rawName:"v-show",value:(_vm.roomName),expression:"roomName"}],staticClass:"buttons"},[_c('button',{attrs:{"disabled":_vm.roomName === ''},on:{"click":function($event){return _vm.checkRoom('create')}}},[_c('span',{staticClass:"btn-text"},[_vm._v(" Create ")])]),_c('button',{attrs:{"disabled":_vm.roomName === ''},on:{"click":function($event){return _vm.checkRoom('join')}}},[_c('span',{staticClass:"btn-text"},[_vm._v(" Connect ")])])]),_c('div',{directives:[{name:"show",rawName:"v-show",value:(_vm.askForPlayerName),expression:"askForPlayerName"}],staticClass:"nick-actions",class:{ popUp: _vm.popUp, 'hide-popUp': _vm.hidePopUp}},[_c('div',{staticClass:"wrapper"},[_c('h2',{directives:[{name:"show",rawName:"v-show",value:(_vm.popUp),expression:"popUp"}]},[_vm._v(" Enter a username to continue ")]),_c('div',{staticClass:"playerName"},[_c('fa',{attrs:{"icon":['fas', 'user']}}),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.playerName),expression:"playerName"}],ref:"playerNameInput",attrs:{"maxlength":"14","type":"text","placeholder":"Nick"},domProps:{"value":(_vm.playerName)},on:{"input":[function($event){if($event.target.composing){ return; }_vm.playerName=$event.target.value},_vm.resetInfoMsg],"keydown":function($event){if(!$event.type.indexOf('key')&&_vm._k($event.keyCode,"enter",13,$event.key,"Enter")){ return null; }return _vm.handleEnter($event)}}})],1),_c('div',{staticClass:"buttons"},[_c('button',{directives:[{name:"show",rawName:"v-show",value:(_vm.action === 'create'),expression:"action === 'create'"}],attrs:{"disabled":!_vm.playerName},on:{"click":_vm.createRoom}},[_c('span',{staticClass:"btn-text"},[_vm._v(" Ok ")])]),_c('button',{directives:[{name:"show",rawName:"v-show",value:(_vm.action === 'join'),expression:"action === 'join'"}],attrs:{"disabled":_vm.playerName === ''},on:{"click":_vm.checkPlayerName}},[_c('span',{staticClass:"btn-text"},[_vm._v(" Join room ")])]),_c('button',{directives:[{name:"show",rawName:"v-show",value:(!_vm.popUp),expression:"!popUp"}],on:{"click":function($event){return _vm.disconnect()}}},[_c('span',{staticClass:"btn-text"},[_vm._v(" Close ")])])])])]),(_vm.roomInfoMsg)?_c('p',{staticClass:"info"},[_vm._v(" "+_vm._s(_vm.roomInfoMsg)+" ")]):_vm._e()]),_c('div',{directives:[{name:"show",rawName:"v-show",value:(_vm.room.connected),expression:"room.connected"}],staticClass:"roomConnected"},[_c('div',{staticClass:"roomNameContainer"},[_c('h2',[_vm._v(_vm._s(_vm.room.name))]),_c('button',{staticClass:"disconnect-btn",on:{"click":function($event){return _vm.disconnect(true)}}},[_c('fa',{attrs:{"icon":['fas', 'sign-out-alt'],"size":"lg"}})],1)]),(_vm.room.owner && _vm.showRoomLink)?_c('div',{staticClass:"popUp"},[_c('p',[_vm._v(" Share this link with other players: ")]),_c('div',{staticClass:"shareLink"},[_c('button',{staticClass:"copy-btn",on:{"click":_vm.copy}},[_c('fa',{attrs:{"icon":['fas', 'copy']}})],1),_c('input',{ref:"shareLink",attrs:{"type":"text","readonly":""},domProps:{"value":(_vm.origin + "/join/" + _vm.roomName)}})]),_c('button',{ref:"closeInfoBtn",staticClass:"close-btn",on:{"click":function($event){if(!$event.type.indexOf('key')&&_vm._k($event.keyCode,"enter",13,$event.key,"Enter")){ return null; }_vm.showRoomLink = false}}},[_c('span',{staticClass:"btn-text"},[_vm._v(" Close ")])])]):_vm._e(),(_vm.room.connected && _vm.$route.path !== '/run')?_c('PlayersList'):_vm._e()],1)])}
var RoomPanelvue_type_template_id_7610ead2_scoped_true_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/RoomPanel.vue?vue&type=template&id=7610ead2&scoped=true&

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"4cb10de2-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/PlayersList.vue?vue&type=template&id=2892573a&scoped=true&
var PlayersListvue_type_template_id_2892573a_scoped_true_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('h4',{staticClass:"players-count"},[_vm._v(" "+_vm._s(Object.keys(_vm.room.players).length === 1 ? '1 player' : Object.keys(_vm.room.players).length + ' players')+" ")]),_c('ol',_vm._l((_vm.sortedPlayers),function(player){return _c('li',{key:player.name},[_c('span',{class:{ owner: player.owner, me: player.name === _vm.room.myName && !_vm.room.owner, winner: player.name === _vm.room.winner }},[_vm._v(_vm._s(player.name)+_vm._s(player.name === _vm.room.myName ? ' (You)' : '')+" "+_vm._s(player.ready && player.connected ? '✔' : '')+" "+_vm._s(player.connected ? '🌐' : '❎'))]),(_vm.$route.path === '/results')?_c('span',[_vm._v(_vm._s(player.stats.time)+"s "+_vm._s(player.stats.wpm)+" WPM")]):_vm._e()])}),0)])}
var PlayersListvue_type_template_id_2892573a_scoped_true_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/PlayersList.vue?vue&type=template&id=2892573a&scoped=true&

// EXTERNAL MODULE: ./node_modules/vuex/dist/vuex.esm.js
var vuex_esm = __webpack_require__("2f62");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/PlayersList.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ var PlayersListvue_type_script_lang_js_ = ({
  name: 'PlayersList',
  computed: {
    ...Object(vuex_esm["b" /* mapGetters */])(['room', 'players']),
    playersArray() {
      console.warn(this.players);
      return Object.entries(this.players).map(([name, data]) => ({ name, ...data }));
    },
    sortedPlayers() {
      console.warn('update sortedPlayers');
      if (this.$route.path === '/results') {
        console.log('results path');
        return this.playersArray.filter((player) => player.stats)
          .sort((p1, p2) => ((p1.time > p2.time) ? 1 : -1));
      }
      return this.playersArray;
    },
  },
  methods: {
  },
});

// CONCATENATED MODULE: ./src/components/PlayersList.vue?vue&type=script&lang=js&
 /* harmony default export */ var components_PlayersListvue_type_script_lang_js_ = (PlayersListvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/components/PlayersList.vue?vue&type=style&index=0&id=2892573a&lang=sass&scoped=true&
var PlayersListvue_type_style_index_0_id_2892573a_lang_sass_scoped_true_ = __webpack_require__("b341");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/components/PlayersList.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  components_PlayersListvue_type_script_lang_js_,
  PlayersListvue_type_template_id_2892573a_scoped_true_render,
  PlayersListvue_type_template_id_2892573a_scoped_true_staticRenderFns,
  false,
  null,
  "2892573a",
  null
  
)

/* harmony default export */ var PlayersList = (component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/RoomPanel.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ var RoomPanelvue_type_script_lang_js_ = ({
  name: 'RoomPanel',
  components: {
    PlayersList: PlayersList,
  },
  data() {
    return {
      roomName: '',
      playerName: '',
      roomInfoMsg: '',
      action: '',
      showRoomCreator: false,
      showRoomLink: true,
      askForPlayerName: false,
      origin: window.location.origin,
      popUp: false,
      hidePopUp: false,
    };
  },
  computed: {
    ...Object(vuex_esm["b" /* mapGetters */])(['room', 'options', 'language']),
  },
  sockets: {
    connect() {
      this.resetInfoMsg();
      console.warn('connected');
    },
    room_created() {
      this.$store.commit('SET_ROOM_PROPERTY', ['connected', true]);
      this.$store.commit('SET_ROOM_PROPERTY', ['name', this.roomName]);
      this.$store.commit('SET_ROOM_PROPERTY', ['myName', this.playerName]);
      this.$store.commit('SET_ROOM_PROPERTY', ['ownerName', this.playerName]);
      this.$store.commit('SET_ROOM_PROPERTY', ['owner', true]);
      this.$store.commit('SET_ROOM_PROPERTY', ['players', {
        [this.playerName]: {
          connected: true,
          ready: true,
          owner: true,
        },
      }]);
      setTimeout(() => this.$refs.closeInfoBtn.focus(), 100);
    },
    room_exist() {
      if (this.action === 'create') {
        console.error('ROOM ALREADY EXIST');
        this.roomInfoMsg = `Room "${this.roomName}" already exists.`;
        this.disconnect();
      } else {
        this.askForPlayerName = true;
        setTimeout(() => this.$refs.playerNameInput.focus(), 100);
      }
    },
    room_dont_exist() {
      if (this.action === 'create') {
        this.askForPlayerName = true;
        setTimeout(() => this.$refs.playerNameInput.focus(), 100);
      } else {
        console.error('ROOM DONT EXIST');
        this.roomInfoMsg = `Room "${this.roomName}" doesn't exist.`;
        this.disconnect();
      }
    },
    player_name_avaible() {
      this.$store.commit('SET_ROOM_PROPERTY', ['myName', this.playerName]);
      this.joinRoom();
    },
    player_name_taken() {
      console.error('PLAYER NAME TAKEN');
      this.roomInfoMsg = `Nick "${this.playerName}" is already taken.`;
    },
  },
  mounted() {
    if (this.$route.params.roomName) {
      this.roomName = this.$route.params.roomName;
      this.popUp = true;
      this.checkRoom('join');
      this.$router.push('/');
    }
  },
  methods: {
    handleEnter() {
      if (this.askForPlayerName) {
        if (this.action === 'create') {
          this.createRoom();
        } else {
          this.checkPlayerName();
        }
      } else {
        this.checkRoom('create');
      }
    },
    checkRoom(action) {
      this.action = action;
      this.$socket.client.io.opts.query = { roomName: this.roomName };
      this.$socket.client.open();
    },
    createRoom() {
      this.$socket.client.emit('createRoom', {
        ownerName: this.playerName,
        roomName: this.roomName,
        options: {
          codeLength: this.options.codeLength,
          autoIndent: this.options.autoIndent,
        },
        languageIndex: this.language.index,
      });
      this.showRoomLink = true;
    },
    checkPlayerName() {
      this.$socket.client.emit('checkPlayerName', this.playerName);
    },
    joinRoom() {
      this.$socket.client.emit('joinRoom');
      this.askForPlayerName = false;
      this.hidePopUp = true;
      setTimeout(() => { this.popUp = false; }, 500);
    },
    disconnect(action = false) {
      this.$socket.client.close();
      this.$store.commit('SET_ROOM_PROPERTY', ['connected', false]);
      this.$store.commit('SET_ROOM_PROPERTY', ['name', '']);
      this.$store.commit('SET_ROOM_PROPERTY', ['owner', false]);
      if (action) {
        this.askForPlayerName = false;
        this.roomName = '';
      } else {
        this.askForPlayerName = false;
      }
    },
    copy() {
      console.log(this.$refs.shareLink);
      this.$refs.shareLink.select();
      document.execCommand('copy');
      console.log('copied');
    },
    resetInfoMsg() {
      this.roomInfoMsg = '';
    },
  },
});

// CONCATENATED MODULE: ./src/components/RoomPanel.vue?vue&type=script&lang=js&
 /* harmony default export */ var components_RoomPanelvue_type_script_lang_js_ = (RoomPanelvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/components/RoomPanel.vue?vue&type=style&index=0&id=7610ead2&lang=sass&scoped=true&
var RoomPanelvue_type_style_index_0_id_7610ead2_lang_sass_scoped_true_ = __webpack_require__("7629");

// CONCATENATED MODULE: ./src/components/RoomPanel.vue






/* normalize component */

var RoomPanel_component = Object(componentNormalizer["a" /* default */])(
  components_RoomPanelvue_type_script_lang_js_,
  RoomPanelvue_type_template_id_7610ead2_scoped_true_render,
  RoomPanelvue_type_template_id_7610ead2_scoped_true_staticRenderFns,
  false,
  null,
  "7610ead2",
  null
  
)

/* harmony default export */ var RoomPanel = (RoomPanel_component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/NavBar.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ var NavBarvue_type_script_lang_js_ = ({
  name: 'NavBar',
  components: {
    RoomPanel: RoomPanel,
  },

  computed: {
    ...Object(vuex_esm["b" /* mapGetters */])(['room', 'language', 'userLanguage']),
  },
  methods: {
    mainPage() {
      if (this.$route.path === '/') {
        if (this.language.name && !this.room.connected) {
          this.$emit('start');
        }
      } else if (this.room.owner) {
        this.$socket.client.emit('reset');
        this.$router.push('/');
      } else {
        this.$router.push('/');
      }
    },
  },
});

// CONCATENATED MODULE: ./src/components/NavBar.vue?vue&type=script&lang=js&
 /* harmony default export */ var components_NavBarvue_type_script_lang_js_ = (NavBarvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/components/NavBar.vue?vue&type=style&index=0&id=7f714fa1&lang=sass&scoped=true&
var NavBarvue_type_style_index_0_id_7f714fa1_lang_sass_scoped_true_ = __webpack_require__("61dc");

// CONCATENATED MODULE: ./src/components/NavBar.vue






/* normalize component */

var NavBar_component = Object(componentNormalizer["a" /* default */])(
  components_NavBarvue_type_script_lang_js_,
  NavBarvue_type_template_id_7f714fa1_scoped_true_render,
  NavBarvue_type_template_id_7f714fa1_scoped_true_staticRenderFns,
  false,
  null,
  "7f714fa1",
  null
  
)

/* harmony default export */ var NavBar = (NavBar_component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"4cb10de2-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/SmallScreen.vue?vue&type=template&id=64a34f77&scoped=true&
var SmallScreenvue_type_template_id_64a34f77_scoped_true_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _vm._m(0)}
var SmallScreenvue_type_template_id_64a34f77_scoped_true_staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"container"},[_c('div',[_c('h2',[_vm._v("Po chuj ci CodeRush na telefonie?"),_c('br'),_c('br'),_vm._v("We detected unsupported screen resolution."),_c('br'),_c('br'),_vm._v("Please open this app on bigger screen (1920x1080). ")])])])}]


// CONCATENATED MODULE: ./src/views/SmallScreen.vue?vue&type=template&id=64a34f77&scoped=true&

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/SmallScreen.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//

/* harmony default export */ var SmallScreenvue_type_script_lang_js_ = ({
  name: 'SmallScreen',
});

// CONCATENATED MODULE: ./src/views/SmallScreen.vue?vue&type=script&lang=js&
 /* harmony default export */ var views_SmallScreenvue_type_script_lang_js_ = (SmallScreenvue_type_script_lang_js_); 
// CONCATENATED MODULE: ./src/views/SmallScreen.vue





/* normalize component */

var SmallScreen_component = Object(componentNormalizer["a" /* default */])(
  views_SmallScreenvue_type_script_lang_js_,
  SmallScreenvue_type_template_id_64a34f77_scoped_true_render,
  SmallScreenvue_type_template_id_64a34f77_scoped_true_staticRenderFns,
  false,
  null,
  "64a34f77",
  null
  
)

/* harmony default export */ var SmallScreen = (SmallScreen_component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/App.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ var Appvue_type_script_lang_js_ = ({
  components: {
    NavBar: NavBar,
    SmallScreen: SmallScreen,
  },
  computed: {
    ...Object(vuex_esm["b" /* mapGetters */])(['room', 'trackedContainers']),
    tooSmall() {
      return window.innerWidth < 640 || window.innerHeight < 480;
    },
    isPlaying() {
      return this.$route.path === '/run';
    },
  },
  created() {
    this.$store.dispatch('loadLanguagesList');
  },
  mounted() {
    if (window.innerWidth > 1300) {
      document.addEventListener('mousemove', this.trackMouse);
      this.$store.commit('ADD_TRACKED_CONTAINER', this.$refs.navLeft);
    }
  },
  methods: {
    trackMouse(ev) {
      if (!this.rafActive) {
        this.rafActive = true;
        requestAnimationFrame(() => {
          this.rafActive = false;
          this.trackedContainers.forEach((element) => {
            // console.log(element.tagName, element.className);
            const pos = element.getBoundingClientRect();
            const x = ev.pageX - pos.left;
            const y = ev.pageY - pos.top;
            element.style.setProperty('--mouse-x', `${x}px`);
            element.style.setProperty('--mouse-y', `${y}px`);
          });
        });
      }
    },
  },
});

// CONCATENATED MODULE: ./src/App.vue?vue&type=script&lang=js&
 /* harmony default export */ var src_Appvue_type_script_lang_js_ = (Appvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/App.vue?vue&type=style&index=0&lang=sass&
var Appvue_type_style_index_0_lang_sass_ = __webpack_require__("cf25");

// CONCATENATED MODULE: ./src/App.vue






/* normalize component */

var App_component = Object(componentNormalizer["a" /* default */])(
  src_Appvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var App = (App_component.exports);
// EXTERNAL MODULE: ./node_modules/vue-router/dist/vue-router.esm.js
var vue_router_esm = __webpack_require__("8c4f");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"4cb10de2-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/Start.vue?vue&type=template&id=40614b6b&scoped=true&
var Startvue_type_template_id_40614b6b_scoped_true_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"start",attrs:{"tabindex":"0"},on:{"!keydown":function($event){if(!$event.type.indexOf('key')&&_vm._k($event.keyCode,"enter",13,$event.key,"Enter")){ return null; }return _vm.handleEnter($event)}}},[_c('main',{staticClass:"middle"},[_c('div',{ref:"scroll",staticClass:"upload-scroll"},[_c('SettingsMenu',{ref:"settings",staticClass:"settings-menu"}),_c('keep-alive',[(_vm.showEditor)?_c('UploadCode',{ref:"code",staticClass:"code-editor"}):_vm._e()],1)],1),_c('p',{directives:[{name:"show",rawName:"v-show",value:(_vm.error),expression:"error"}],staticClass:"error"},[_vm._v(" "+_vm._s(_vm.error)+" ")]),_c('div',{staticClass:"buttons-bottom"},[_c('label',{staticClass:"button show-editor-btn"},[_c('span',[_vm._v(_vm._s(_vm.uploadCodeText))]),_c('input',{attrs:{"disabled":_vm.room.connected && !_vm.room.owner,"type":"checkbox"},domProps:{"checked":_vm.customCode.showEditor},on:{"input":function($event){return _vm.useCustomCode($event.target.checked)}}})]),(_vm.room.connected && !_vm.room.owner)?_c('label',{staticClass:"button ready-btn",class:{ highlight: _vm.isReady }},[_c('span',[_vm._v("Ready")]),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.isReady),expression:"isReady"}],attrs:{"type":"checkbox"},domProps:{"checked":Array.isArray(_vm.isReady)?_vm._i(_vm.isReady,null)>-1:(_vm.isReady)},on:{"input":function($event){return _vm.ready($event.target.checked)},"change":function($event){var $$a=_vm.isReady,$$el=$event.target,$$c=$$el.checked?(true):(false);if(Array.isArray($$a)){var $$v=null,$$i=_vm._i($$a,$$v);if($$el.checked){$$i<0&&(_vm.isReady=$$a.concat([$$v]))}else{$$i>-1&&(_vm.isReady=$$a.slice(0,$$i).concat($$a.slice($$i+1)))}}else{_vm.isReady=$$c}}}})]):_vm._e(),_c('button',{staticClass:"button start-btn",class:{ highlight: _vm.language.name },attrs:{"disabled":_vm.room.connected && !_vm.room.owner},on:{"click":_vm.run}},[_vm._v(" START ")])])]),_c('LanguagesList',{ref:"languagesList",staticClass:"languages-list"})],1)}
var Startvue_type_template_id_40614b6b_scoped_true_staticRenderFns = []


// CONCATENATED MODULE: ./src/views/Start.vue?vue&type=template&id=40614b6b&scoped=true&

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"4cb10de2-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/SettingsMenu.vue?vue&type=template&id=7a2cc102&scoped=true&
var SettingsMenuvue_type_template_id_7a2cc102_scoped_true_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('main',{on:{"!input":function($event){return _vm.updateOption($event)}}},[_c('h2',[_vm._v("How do you want to play?")]),_c('p',{staticClass:"select-text"},[_vm._v(" Game mode ")]),_c('div',{ref:"modesList",staticClass:"modes list"},_vm._l((_vm.modesList),function(mode,index){return _c('label',{key:mode[0],staticClass:"mode",class:{'selected': index+1 === _vm.selectedMode}},[_c('h4',[_vm._v(_vm._s(mode[0]))]),_c('p',{staticClass:"modeDesc"},[_vm._v(_vm._s(mode[1]))]),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.selectedMode),expression:"selectedMode"}],attrs:{"name":"mode","type":"radio"},domProps:{"value":index+1,"checked":_vm._q(_vm.selectedMode,index+1)},on:{"change":function($event){_vm.selectedMode=index+1}}})])}),0),_c('p',{staticClass:"select-text"},[_vm._v(" Source code theme ")]),_c('div',{ref:"themesList",staticClass:"themes list"},_vm._l((_vm.themesList),function(theme){return _c('label',{key:theme[0],staticClass:"theme",class:{'selected': theme[0] === _vm.selectedTheme}},[_c('h4',[_vm._v(_vm._s(theme[1]))]),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.selectedTheme),expression:"selectedTheme"}],attrs:{"type":"radio"},domProps:{"value":theme[0],"checked":_vm._q(_vm.selectedTheme,theme[0])},on:{"change":function($event){_vm.selectedTheme=theme[0]}}})])}),0),_c('div',{staticClass:"toggles"},[_c('label',[_c('span',[_vm._v("Highlight next character")]),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.underScore),expression:"underScore"}],attrs:{"type":"checkbox"},domProps:{"checked":Array.isArray(_vm.underScore)?_vm._i(_vm.underScore,null)>-1:(_vm.underScore)},on:{"change":function($event){var $$a=_vm.underScore,$$el=$event.target,$$c=$$el.checked?(true):(false);if(Array.isArray($$a)){var $$v=null,$$i=_vm._i($$a,$$v);if($$el.checked){$$i<0&&(_vm.underScore=$$a.concat([$$v]))}else{$$i>-1&&(_vm.underScore=$$a.slice(0,$$i).concat($$a.slice($$i+1)))}}else{_vm.underScore=$$c}}}}),_c('div',{staticClass:"slider"})]),_c('label',[_c('span',[_vm._v("Auto-indent new line")]),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.autoIndent),expression:"autoIndent"}],attrs:{"disabled":_vm.block,"name":"autoIndent","type":"checkbox"},domProps:{"checked":Array.isArray(_vm.autoIndent)?_vm._i(_vm.autoIndent,null)>-1:(_vm.autoIndent)},on:{"change":function($event){var $$a=_vm.autoIndent,$$el=$event.target,$$c=$$el.checked?(true):(false);if(Array.isArray($$a)){var $$v=null,$$i=_vm._i($$a,$$v);if($$el.checked){$$i<0&&(_vm.autoIndent=$$a.concat([$$v]))}else{$$i>-1&&(_vm.autoIndent=$$a.slice(0,$$i).concat($$a.slice($$i+1)))}}else{_vm.autoIndent=$$c}}}}),_c('div',{staticClass:"slider"})]),_c('label',[_c('span',[_vm._v("Only short levels")]),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.codeLength),expression:"codeLength"}],attrs:{"disabled":_vm.block,"name":"codeLength","type":"checkbox"},domProps:{"checked":Array.isArray(_vm.codeLength)?_vm._i(_vm.codeLength,null)>-1:(_vm.codeLength)},on:{"change":function($event){var $$a=_vm.codeLength,$$el=$event.target,$$c=$$el.checked?(true):(false);if(Array.isArray($$a)){var $$v=null,$$i=_vm._i($$a,$$v);if($$el.checked){$$i<0&&(_vm.codeLength=$$a.concat([$$v]))}else{$$i>-1&&(_vm.codeLength=$$a.slice(0,$$i).concat($$a.slice($$i+1)))}}else{_vm.codeLength=$$c}}}}),_c('div',{staticClass:"slider"})]),_c('label',[_c('span',[_vm._v("Show line numbers")]),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.lineNumbers),expression:"lineNumbers"}],attrs:{"type":"checkbox"},domProps:{"checked":Array.isArray(_vm.lineNumbers)?_vm._i(_vm.lineNumbers,null)>-1:(_vm.lineNumbers)},on:{"change":function($event){var $$a=_vm.lineNumbers,$$el=$event.target,$$c=$$el.checked?(true):(false);if(Array.isArray($$a)){var $$v=null,$$i=_vm._i($$a,$$v);if($$el.checked){$$i<0&&(_vm.lineNumbers=$$a.concat([$$v]))}else{$$i>-1&&(_vm.lineNumbers=$$a.slice(0,$$i).concat($$a.slice($$i+1)))}}else{_vm.lineNumbers=$$c}}}}),_c('div',{staticClass:"slider"})])])])}
var SettingsMenuvue_type_template_id_7a2cc102_scoped_true_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/SettingsMenu.vue?vue&type=template&id=7a2cc102&scoped=true&

// EXTERNAL MODULE: ./node_modules/vuex-map-fields/dist/index.esm.js
var index_esm = __webpack_require__("5935");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/SettingsMenu.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




const { mapFields } = Object(index_esm["a" /* createHelpers */])({
  getterType: 'getOption',
  mutationType: 'UPDATE_OPTION',
});
/* harmony default export */ var SettingsMenuvue_type_script_lang_js_ = ({
  name: 'SettingsMenu',
  data() {
    return {
      themesList: [
        ['material-darker', 'Material Dark'],
        ['one-dark', 'Atom One Dark'],
        ['Base2Tone-Suburb-dark', 'Base2Tone Suburb Dark'],
        ['', 'Plain white'],
      ],
      modesList: [
        ['Normal', 'Write down provided source code as quickly as you can.'],
        ['Hardcore', 'Just don\'t make any mistakes.'],
        ['CodeRush', 'See how much code you are able to write in 100 seconds'],
      ],
    };
  },
  computed: {
    ...Object(vuex_esm["b" /* mapGetters */])(['room', 'customCode']),
    ...mapFields(['selectedTheme', 'selectedMode', 'underScore', 'codeLength', 'lineNumbers', 'autoIndent']),
    block() {
      return this.room.connected && !this.room.owner;
    },
  },
  activated() {
    this.$store.commit('ADD_TRACKED_CONTAINER', this.$refs.modesList);
    this.$store.commit('ADD_TRACKED_CONTAINER', this.$refs.themesList);
  },
  deactivated() {
    this.$store.commit('REMOVE_TRACKED_CONTAINER', this.$refs.modesList.className);
    this.$store.commit('REMOVE_TRACKED_CONTAINER', this.$refs.themesList.className);
  },
  methods: {
    updateOption(ev) {
      if (this.room.owner && ev.target.name) {
        this.$socket.client.emit('optionChange', { name: ev.target.name, value: ev.target.checked });
      }
    },
  },
});

// CONCATENATED MODULE: ./src/components/SettingsMenu.vue?vue&type=script&lang=js&
 /* harmony default export */ var components_SettingsMenuvue_type_script_lang_js_ = (SettingsMenuvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/components/SettingsMenu.vue?vue&type=style&index=0&id=7a2cc102&lang=sass&scoped=true&
var SettingsMenuvue_type_style_index_0_id_7a2cc102_lang_sass_scoped_true_ = __webpack_require__("3a6a");

// CONCATENATED MODULE: ./src/components/SettingsMenu.vue






/* normalize component */

var SettingsMenu_component = Object(componentNormalizer["a" /* default */])(
  components_SettingsMenuvue_type_script_lang_js_,
  SettingsMenuvue_type_template_id_7a2cc102_scoped_true_render,
  SettingsMenuvue_type_template_id_7a2cc102_scoped_true_staticRenderFns,
  false,
  null,
  "7a2cc102",
  null
  
)

/* harmony default export */ var SettingsMenu = (SettingsMenu_component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"4cb10de2-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/LanguagesList.vue?vue&type=template&id=2b6d3ee5&scoped=true&
var LanguagesListvue_type_template_id_2b6d3ee5_scoped_true_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('div',{staticClass:"search"},[_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.searchText),expression:"searchText"}],staticClass:"searchInput",attrs:{"type":"text","placeholder":"Search","maxlength":"12","autofocus":""},domProps:{"value":(_vm.searchText)},on:{"keydown":function($event){if(!$event.type.indexOf('key')&&_vm._k($event.keyCode,"enter",13,$event.key,"Enter")){ return null; }$event.stopPropagation();return _vm.selectFirstFromSearch($event)},"input":function($event){if($event.target.composing){ return; }_vm.searchText=$event.target.value}}}),_c('div',[_c('span',{directives:[{name:"show",rawName:"v-show",value:(_vm.searchText && _vm.filteredList.length === _vm.languagesList.length),expression:"searchText && filteredList.length === languagesList.length"}],staticClass:"nothing-found-text"},[_vm._v("(nothing found)")]),_c('button',{directives:[{name:"show",rawName:"v-show",value:(_vm.searchText),expression:"searchText"}],staticClass:"clear-btn",on:{"click":_vm.clear}},[_vm._v(" Clear ")])])]),_c('div',{ref:"languagesList",staticClass:"languages list"},[_c('button',{staticClass:"language random",class:{'selected': _vm.language.index === null},attrs:{"disabled":_vm.room.connected && !_vm.room.owner},on:{"click":_vm.selectRandom}},[_vm._v(" Random ")]),_vm._l((_vm.filteredList),function(filteredLanguage,index){return _c('label',{key:filteredLanguage.name === 'Loading...' ? index : filteredLanguage.name,staticClass:"language",class:{'selected':_vm.language.index === filteredLanguage.index}},[_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.language),expression:"language"}],staticClass:"language-radio",attrs:{"type":"radio","disabled":_vm.room.connected && !_vm.room.owner,"index":filteredLanguage.index},domProps:{"value":_vm.languagesList[filteredLanguage.index],"checked":_vm._q(_vm.language,_vm.languagesList[filteredLanguage.index])},on:{"input":_vm.setRoomLanguage,"change":function($event){_vm.language=_vm.languagesList[filteredLanguage.index]}}}),_c('span',{staticClass:"language-name"},[_vm._v(_vm._s(filteredLanguage.name.replace('_', ' ')))]),_c('span',{staticClass:"stat"},[_c('span',[_vm._v("24")]),_c('fa',{staticClass:"icon",attrs:{"icon":['fas', 'users']}})],1)])})],2)])}
var LanguagesListvue_type_template_id_2b6d3ee5_scoped_true_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/LanguagesList.vue?vue&type=template&id=2b6d3ee5&scoped=true&

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/LanguagesList.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




// The getter and mutation types we're providing
// here, must be the same as the function names we've
// used in the store.
const { mapFields: LanguagesListvue_type_script_lang_js_mapFields } = Object(index_esm["a" /* createHelpers */])({
  getterType: 'getLanguage',
  mutationType: 'UPDATE_LANGUAGE',
});
/* harmony default export */ var LanguagesListvue_type_script_lang_js_ = ({
  data() {
    return {
      searchText: '',
    };
  },
  computed: {
    ...Object(vuex_esm["b" /* mapGetters */])(['languagesList', 'room']),
    ...LanguagesListvue_type_script_lang_js_mapFields(['language']),
    filteredList() {
      if (this.languagesList.length) {
        const search = this.searchText.toLowerCase();
        const filtered = this.languagesList
          .filter((language) => language.name.toLowerCase().includes(search))
          .sort((a, b) => (b.name.toLowerCase().startsWith(search) ? 1 : -1));
        return filtered.length > 0 ? filtered : this.languagesList;
      }
      return [...Array(29)].map(() => ({ name: 'Loading...' }));
    },
  },
  activated() {
    this.$store.commit('ADD_TRACKED_CONTAINER', this.$refs.languagesList);
  },
  deactivated() {
    this.$store.commit('REMOVE_TRACKED_CONTAINER', this.$refs.languagesList.className);
  },
  // activated() {
  //   if (this.language.index) {
  //     console.warn('updating selected language');
  //     this.selected = this.language.index;
  //   }
  // },
  methods: {
    clear() {
      this.searchText = '';
    },
    selectRandom() {
      const index = Math.floor(Math.random() * this.filteredList.length);
      if (this.filteredList[index].index === this.language.index && this.filteredList.length > 1) {
        this.selectRandom();
      } else {
        this.language = this.filteredList[index];
        if (this.room.owner) {
          this.$socket.client.emit('languageChange', index);
        }
      }
    },
    selectFirstFromSearch() {
      console.green('ENTER');
      if (this.filteredList.length !== 0 && this.filteredList.length < this.languagesList.length) {
        [this.language] = this.filteredList;
      } else {
        this.clear();
      }
    },
    setRoomLanguage(ev) {
      if (this.room.owner) {
        this.$nextTick(() => this.$socket.client.emit('languageChange', ev.target.getAttribute('index')));
      }
    },
  },
});

// CONCATENATED MODULE: ./src/components/LanguagesList.vue?vue&type=script&lang=js&
 /* harmony default export */ var components_LanguagesListvue_type_script_lang_js_ = (LanguagesListvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/components/LanguagesList.vue?vue&type=style&index=0&id=2b6d3ee5&lang=sass&scoped=true&
var LanguagesListvue_type_style_index_0_id_2b6d3ee5_lang_sass_scoped_true_ = __webpack_require__("941e");

// CONCATENATED MODULE: ./src/components/LanguagesList.vue






/* normalize component */

var LanguagesList_component = Object(componentNormalizer["a" /* default */])(
  components_LanguagesListvue_type_script_lang_js_,
  LanguagesListvue_type_template_id_2b6d3ee5_scoped_true_render,
  LanguagesListvue_type_template_id_2b6d3ee5_scoped_true_staticRenderFns,
  false,
  null,
  "2b6d3ee5",
  null
  
)

/* harmony default export */ var LanguagesList = (LanguagesList_component.exports);
// EXTERNAL MODULE: ./src/components/UploadCode.vue + 4 modules
var UploadCode = __webpack_require__("8d8e");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/Start.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





// const UploadCode = () => import(/* webpackChunkName: "upload-code" */ '@/components/UploadCode.vue');

/* harmony default export */ var Startvue_type_script_lang_js_ = ({
  name: 'Start',
  components: {
    SettingsMenu: SettingsMenu,
    LanguagesList: LanguagesList,
    UploadCode: UploadCode["a" /* default */],
  },
  data() {
    return {
      showEditor: false,
      uploadCodeText: 'Use your own code',
      error: '',
      isReady: false,
    };
  },

  computed: {
    ...Object(vuex_esm["b" /* mapGetters */])(['room', 'language', 'options', 'customCode']),
    playersReady() {
      return Object.values(this.room.players).every((player) => player.ready);
    },
  },
  watch: {
    language(current, previous) {
      console.warn('watch');
      console.log(previous);
      if (previous.index) {
        this.error = '';
      }
    },
  },
  activated() {
    if (this.customCode.showEditor) {
      this.$refs.code.$refs.codemirror.$el.scrollIntoView({
        block: 'start',
        inline: 'nearest',
      });
    }
  },
  methods: {
    handleEnter() {
      console.blue('ENTER');
    },
    useCustomCode(value) {
      console.warn('usecustomcode', value);
      if (value) {
        this.showEditor = value;
        this.$store.commit('USE_CUSTOM_CODE', true);

        setTimeout(() => {
          // this.$refs.code.$el.style.display = 'flex';
          this.$refs.code.$refs.codemirror.$el.scrollIntoView({
            block: 'start',
            inline: 'nearest',
            behavior: 'smooth',
          });
        }, 30);
      } else {
        this.error = '';
        this.$store.dispatch('deleteCustomCode');
        this.$refs.settings.$el.scrollIntoView({
          block: 'start',
          inline: 'nearest',
          behavior: 'smooth',
        });

        setTimeout(() => {
          this.showEditor = value;
        }, 500);
      }
      if (this.room.owner) {
        this.$socket.client.emit('useCustomCode', value);
      }




      this.uploadCodeText = value ? 'Cancel' : 'Use your own code';
    },
    run() {
      if (!this.language.name) {
        this.$refs.languagesList.selectRandom();
        // this.error = `We picked ${this.language.name} for you. You can choose a different one from the list on the right or click start to continue`;
        // return;
      }

      if (!this.error) { // second click ignores
        if (this.showEditor && (this.customCode.text.length < 30 || this.customCode.lines < 4)) {
          this.error = 'Provided code is too short too produce accurate results.';
          return;
        }


        if (this.room.connected && !this.playersReady) {
          this.error = 'Some players aren\'t ready yet. Click again to ignore';
          return;
        }
      }

      if (this.showEdiotr && this.room.owner) {
        this.$socket.client.emit('customCodeData', this.customCode);
      }

      this.prepareCodeInfo();
      if (this.room.owner) {
        this.$socket.client.emit('start', Date.now());
      }
      if (window.location.hash || localStorage.getItem('myUniverse')) {
        localStorage.setItem('myUniverse', true);
        this.$router.push('myuniverse');
      } else {
        this.$router.push('run');
      }
    },
    ready(value) {
      this.$socket.client.emit('playerStateChange', value);
    },
    prepareCodeInfo() {
      let fileIndex = -1;
      if (!this.customCode.text) {
        fileIndex = Math.floor(Math.random() * this.language.files.length);
      }
      this.$store.dispatch('generateCodeInfo', fileIndex);
      if (this.room.owner) {
        this.$socket.client.emit('fileIndex', fileIndex);
      }
    },
  },
  sockets: {
    start(ownerStartTime) {
      this.$store.commit('LATENCY', ownerStartTime);
      this.$router.push('run');
    },
  },
});

// CONCATENATED MODULE: ./src/views/Start.vue?vue&type=script&lang=js&
 /* harmony default export */ var views_Startvue_type_script_lang_js_ = (Startvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/views/Start.vue?vue&type=style&index=0&id=40614b6b&lang=sass&scoped=true&
var Startvue_type_style_index_0_id_40614b6b_lang_sass_scoped_true_ = __webpack_require__("7447");

// CONCATENATED MODULE: ./src/views/Start.vue






/* normalize component */

var Start_component = Object(componentNormalizer["a" /* default */])(
  views_Startvue_type_script_lang_js_,
  Startvue_type_template_id_40614b6b_scoped_true_render,
  Startvue_type_template_id_40614b6b_scoped_true_staticRenderFns,
  false,
  null,
  "40614b6b",
  null
  
)

/* harmony default export */ var Start = (Start_component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"4cb10de2-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/PageNotFound.vue?vue&type=template&id=ab0b278c&
var PageNotFoundvue_type_template_id_ab0b278c_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div')}
var PageNotFoundvue_type_template_id_ab0b278c_staticRenderFns = []


// CONCATENATED MODULE: ./src/views/PageNotFound.vue?vue&type=template&id=ab0b278c&

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/PageNotFound.vue?vue&type=script&lang=js&
//
//
//
//


/* harmony default export */ var PageNotFoundvue_type_script_lang_js_ = ({
  name: 'PageNotFound',
  created() {
    this.$router.push('/');
  },
});

// CONCATENATED MODULE: ./src/views/PageNotFound.vue?vue&type=script&lang=js&
 /* harmony default export */ var views_PageNotFoundvue_type_script_lang_js_ = (PageNotFoundvue_type_script_lang_js_); 
// CONCATENATED MODULE: ./src/views/PageNotFound.vue





/* normalize component */

var PageNotFound_component = Object(componentNormalizer["a" /* default */])(
  views_PageNotFoundvue_type_script_lang_js_,
  PageNotFoundvue_type_template_id_ab0b278c_render,
  PageNotFoundvue_type_template_id_ab0b278c_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var PageNotFound = (PageNotFound_component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"4cb10de2-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/Run.vue?vue&type=template&id=0f118d76&scoped=true&
var Runvue_type_template_id_0f118d76_scoped_true_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('main',{key:_vm.resetSelfKey,class:{wide: _vm.stats },on:{"keydown":function($event){if(!$event.altKey){ return null; }return _vm.resetSelf($event)}}},[_c('div',{staticClass:"top-bar"},[(_vm.requestReset)?[_vm._m(0),_c('div',{staticClass:"buttons"},[_c('button',{on:{"click":function($event){return _vm.$router.push('/')}}},[_vm._v(" OK ")]),_c('button',{staticClass:"disconnect-btn",on:{"click":_vm.disconnect}},[_vm._v(" Leave room and stay here ")])])]:[_c('div',{staticClass:"info"},[_c('div',{staticClass:"languageName"},[_c('h2',[_vm._v(_vm._s(_vm.languageName))])]),_c('div',{staticClass:"codeInfo"},[(_vm.codeInfo.name)?_c('p',[_vm._v(" "+_vm._s(_vm.codeInfo.name)+"."+_vm._s(_vm.language.ext)+" ")]):_vm._e(),_c('p',[_vm._v(_vm._s(_vm.codeSource))])])]),_c('div',{staticClass:"buttons"},[_c('button',{staticClass:"reset",attrs:{"disabled":_vm.room.connected},on:{"click":_vm.reset}},[_vm._v(" Restart ")]),_c('button',{directives:[{name:"show",rawName:"v-show",value:(_vm.$route.path !== '/results'),expression:"$route.path !== '/results'"}],staticClass:"finish",attrs:{"disabled":_vm.room.connected},on:{"click":_vm.finish}},[_vm._v(" Finish now ")])])]],2),(_vm.language.name)?_c('CodeEditor',{key:_vm.resetEditorKey,ref:"codeEditor",staticClass:"code-editor",on:{"reset":_vm.reset,"completed":_vm.completed}}):_vm._e(),_c('div',{directives:[{name:"show",rawName:"v-show",value:(_vm.$route.path === '/results' && _vm.stats),expression:"$route.path === '/results' && stats"}],ref:"results",staticClass:"results"},[(_vm.stats)?_c('Results',{attrs:{"stats":_vm.stats}}):_vm._e()],1)],1)}
var Runvue_type_template_id_0f118d76_scoped_true_staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"info"},[_c('div',{staticClass:"codeInfo"},[_c('h2',[_vm._v("Room owner wants to start a new game")]),_c('p',[_vm._v("You will be moved to lobby")])])])}]


// CONCATENATED MODULE: ./src/views/Run.vue?vue&type=template&id=0f118d76&scoped=true&

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"4cb10de2-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/CodeEditor.vue?vue&type=template&id=a9580c94&scoped=true&
var CodeEditorvue_type_template_id_a9580c94_scoped_true_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{ref:"container",staticClass:"container"},[_c('div',{staticClass:"code",class:{ready: _vm.cmReady, completed: _vm.isCompleted},on:{"!keydown":function($event){$event.preventDefault();return _vm.onKeyDown($event)}}},[_c('codemirror',{ref:"codemirror",staticClass:"codemirror",class:{showInvisibles: _vm.language.name === 'Whitespace'},attrs:{"options":_vm.cmOptions},on:{"ready":_vm.onCmReady,"blur":_vm.onUnFocus},model:{value:(_vm.codeText),callback:function ($$v) {_vm.codeText=$$v},expression:"codeText"}})],1),_c('div',{staticClass:"pop-up",class:{hidden: !_vm.showPopUp, clickable: _vm.popUpClickable, 'small-font': _vm.popUpText.length > 15}},[_c('div',[_c('h2',{on:{"click":function($event){return _vm.popUp(false)}}},[_vm._v(" "+_vm._s(_vm.popUpText)+" ")]),_c('p',{directives:[{name:"show",rawName:"v-show",value:(_vm.isCompleted),expression:"isCompleted"}]},[_vm._v(" Loading your results... ")])])])])}
var CodeEditorvue_type_template_id_a9580c94_scoped_true_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/CodeEditor.vue?vue&type=template&id=a9580c94&scoped=true&

// EXTERNAL MODULE: ./node_modules/axios/index.js
var axios = __webpack_require__("bc3a");
var axios_default = /*#__PURE__*/__webpack_require__.n(axios);

// CONCATENATED MODULE: ./src/stats2.js
/* eslint-disable */
/* harmony default export */ var stats2 = ({
  "history": [
    {
      "time": 0,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 78,
      "text": "n"
    },
    {
      "time": 61,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 85,
      "text": "u"
    },
    {
      "time": 237,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 77,
      "text": "m"
    },
    {
      "time": 709,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 789,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 187,
      "text": "="
    },
    {
      "time": 901,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 1301,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 65,
      "text": "a"
    },
    {
      "time": 1405,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 83,
      "text": "s"
    },
    {
      "time": 1677,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 190,
      "text": "."
    },
    {
      "time": 1901,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 2005,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 78,
      "text": "n"
    },
    {
      "time": 2062,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 84,
      "text": "t"
    },
    {
      "time": 2159,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 69,
      "text": "e"
    },
    {
      "time": 2357,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 71,
      "text": "g"
    },
    {
      "time": 2501,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 69,
      "text": "e"
    },
    {
      "time": 2965,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 3269,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 57,
      "text": "("
    },
    {
      "time": 3573,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 3686,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 69,
      "text": "e"
    },
    {
      "time": 3757,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 65,
      "text": "a"
    },
    {
      "time": 3885,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 68,
      "text": "d"
    },
    {
      "time": 3997,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 76,
      "text": "l"
    },
    {
      "time": 4173,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 4238,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 78,
      "text": "n"
    },
    {
      "time": 4350,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 69,
      "text": "e"
    },
    {
      "time": 4509,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 57,
      "text": "("
    },
    {
      "time": 4742,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 80,
      "text": "p"
    },
    {
      "time": 4870,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 4966,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 79,
      "text": "o"
    },
    {
      "time": 5053,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 77,
      "text": "m"
    },
    {
      "time": 5189,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 80,
      "text": "p"
    },
    {
      "time": 5318,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 84,
      "text": "t"
    },
    {
      "time": 5558,
      "type": "mistake",
      "shift": true,
      "alt": false,
      "keyCode": 187,
      "fixQueuePos": 1,
      "expectedText": "=",
      "text": "+"
    },
    {
      "time": 6238,
      "type": "backspace",
      "shift": false,
      "alt": false,
      "keyCode": 8,
      "fixQueuePos": 0
    },
    {
      "time": 6494,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 187,
      "text": "="
    },
    {
      "time": 6942,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 222,
      "text": "\""
    },
    {
      "time": 7270,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 69,
      "text": "E"
    },
    {
      "time": 7462,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 78,
      "text": "n"
    },
    {
      "time": 7566,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 84,
      "text": "t"
    },
    {
      "time": 7670,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 69,
      "text": "e"
    },
    {
      "time": 7798,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 8086,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 8262,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 8350,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 78,
      "text": "n"
    },
    {
      "time": 8454,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 84,
      "text": "t"
    },
    {
      "time": 8934,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 186,
      "text": ":"
    },
    {
      "time": 9478,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 10310,
      "type": "mistake",
      "shift": false,
      "alt": false,
      "keyCode": 222,
      "fixQueuePos": 1,
      "expectedText": "\"",
      "text": "'"
    },
    {
      "time": 10678,
      "type": "mistake",
      "shift": true,
      "alt": false,
      "keyCode": 222,
      "fixQueuePos": 2,
      "expectedText": ")",
      "text": "\""
    },
    {
      "time": 11158,
      "type": "backspace",
      "shift": false,
      "alt": false,
      "keyCode": 8,
      "fixQueuePos": 1
    },
    {
      "time": 11504,
      "type": "backspace",
      "shift": false,
      "alt": false,
      "keyCode": 8,
      "fixQueuePos": 0
    },
    {
      "time": 12071,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 222,
      "text": "\""
    },
    {
      "time": 12799,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 48,
      "text": ")"
    },
    {
      "time": 13127,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 48,
      "text": ")"
    },
    {
      "time": 13623,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 13
    },
    {
      "time": 14095,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 70,
      "text": "f"
    },
    {
      "time": 14175,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 65,
      "text": "a"
    },
    {
      "time": 14311,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 67,
      "text": "c"
    },
    {
      "time": 14583,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 84,
      "text": "t"
    },
    {
      "time": 14663,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 79,
      "text": "o"
    },
    {
      "time": 14799,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 14919,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 15039,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 65,
      "text": "a"
    },
    {
      "time": 15167,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 76,
      "text": "l"
    },
    {
      "time": 15327,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 15447,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 187,
      "text": "="
    },
    {
      "time": 15679,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 15759,
      "type": "mistake",
      "shift": false,
      "alt": false,
      "keyCode": 50,
      "fixQueuePos": 1,
      "expectedText": "1",
      "text": "2"
    },
    {
      "time": 16151,
      "type": "backspace",
      "shift": false,
      "alt": false,
      "keyCode": 8,
      "fixQueuePos": 0
    },
    {
      "time": 16911,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 49,
      "text": "1"
    },
    {
      "time": 17359,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 13
    },
    {
      "time": 17943,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 18039,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 70,
      "text": "f"
    },
    {
      "time": 18175,
      "type": "mistake",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "fixQueuePos": 1,
      "expectedText": "(",
      "text": " "
    },
    {
      "time": 18391,
      "type": "mistake",
      "shift": true,
      "alt": false,
      "keyCode": 57,
      "fixQueuePos": 2,
      "expectedText": "n",
      "text": "("
    },
    {
      "time": 18855,
      "type": "backspace",
      "shift": false,
      "alt": false,
      "keyCode": 8,
      "fixQueuePos": 1
    },
    {
      "time": 18959,
      "type": "backspace",
      "shift": false,
      "alt": false,
      "keyCode": 8,
      "fixQueuePos": 0
    },
    {
      "time": 19183,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 57,
      "text": "("
    },
    {
      "time": 19560,
      "type": "mistake",
      "shift": false,
      "alt": false,
      "keyCode": 85,
      "fixQueuePos": 1,
      "expectedText": "n",
      "text": "u"
    },
    {
      "time": 19879,
      "type": "backspace",
      "shift": false,
      "alt": false,
      "keyCode": 8,
      "fixQueuePos": 0
    },
    {
      "time": 20136,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 78,
      "text": "n"
    },
    {
      "time": 20224,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 85,
      "text": "u"
    },
    {
      "time": 20440,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 77,
      "text": "m"
    },
    {
      "time": 20608,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 20760,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 188,
      "text": "<"
    },
    {
      "time": 21872,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 22080,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 48,
      "text": "0"
    },
    {
      "time": 22656,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 48,
      "text": ")"
    },
    {
      "time": 22888,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 23208,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 219,
      "text": "{"
    },
    {
      "time": 23552,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 13
    },
    {
      "time": 24080,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 80,
      "text": "p"
    },
    {
      "time": 24256,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 24408,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 24568,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 78,
      "text": "n"
    },
    {
      "time": 24712,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 84,
      "text": "t"
    },
    {
      "time": 25640,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 57,
      "text": "("
    },
    {
      "time": 26737,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 222,
      "text": "\""
    },
    {
      "time": 27321,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 69,
      "text": "E"
    },
    {
      "time": 27585,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 27745,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 27833,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 79,
      "text": "o"
    },
    {
      "time": 27938,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 28897,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 186,
      "text": ":"
    },
    {
      "time": 29153,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 29257,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 77,
      "text": "m"
    },
    {
      "time": 29441,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 85,
      "text": "u"
    },
    {
      "time": 29578,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 83,
      "text": "s"
    },
    {
      "time": 29777,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 84,
      "text": "t"
    },
    {
      "time": 29937,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 30049,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 66,
      "text": "b"
    },
    {
      "time": 30193,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 69,
      "text": "e"
    },
    {
      "time": 30642,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 31210,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 187,
      "text": "+"
    },
    {
      "time": 32258,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 222,
      "text": "\""
    },
    {
      "time": 33274,
      "type": "mistake",
      "shift": true,
      "alt": false,
      "keyCode": 57,
      "fixQueuePos": 1,
      "expectedText": ")",
      "text": "("
    },
    {
      "time": 33922,
      "type": "backspace",
      "shift": false,
      "alt": false,
      "keyCode": 8,
      "fixQueuePos": 0
    },
    {
      "time": 34242,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 48,
      "text": ")"
    },
    {
      "time": 34874,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 13
    },
    {
      "time": 35994,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 221,
      "text": "}"
    },
    {
      "time": 36386,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 13
    },
    {
      "time": 37642,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 38267,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 69,
      "text": "e"
    },
    {
      "time": 38418,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 76,
      "text": "l"
    },
    {
      "time": 38579,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 83,
      "text": "s"
    },
    {
      "time": 38667,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 69,
      "text": "e"
    },
    {
      "time": 39211,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 39699,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 39795,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 70,
      "text": "f"
    },
    {
      "time": 40851,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 57,
      "text": "("
    },
    {
      "time": 41443,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 78,
      "text": "n"
    },
    {
      "time": 41579,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 85,
      "text": "u"
    },
    {
      "time": 41827,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 77,
      "text": "m"
    },
    {
      "time": 42371,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 42579,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 187,
      "text": "="
    },
    {
      "time": 42707,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 187,
      "text": "="
    },
    {
      "time": 43459,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 43572,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 48,
      "text": "0"
    },
    {
      "time": 44556,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 48,
      "text": ")"
    },
    {
      "time": 44844,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 45076,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 219,
      "text": "{"
    },
    {
      "time": 45428,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 13
    },
    {
      "time": 46036,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 80,
      "text": "p"
    },
    {
      "time": 46182,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 46284,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 46364,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 78,
      "text": "n"
    },
    {
      "time": 46492,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 84,
      "text": "t"
    },
    {
      "time": 47412,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 57,
      "text": "("
    },
    {
      "time": 47724,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 222,
      "text": "\""
    },
    {
      "time": 48468,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 49,
      "text": "1"
    },
    {
      "time": 48932,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 222,
      "text": "\""
    },
    {
      "time": 49420,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 48,
      "text": ")"
    },
    {
      "time": 49884,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 13
    },
    {
      "time": 50524,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 221,
      "text": "}"
    },
    {
      "time": 51341,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 13
    },
    {
      "time": 52885,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 53613,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 69,
      "text": "e"
    },
    {
      "time": 53725,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 76,
      "text": "l"
    },
    {
      "time": 53853,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 83,
      "text": "s"
    },
    {
      "time": 54004,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 69,
      "text": "e"
    },
    {
      "time": 54453,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 54733,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 219,
      "text": "{"
    },
    {
      "time": 55133,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 13
    },
    {
      "time": 55765,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 70,
      "text": "f"
    },
    {
      "time": 55869,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 79,
      "text": "o"
    },
    {
      "time": 56013,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 56285,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 57,
      "text": "("
    },
    {
      "time": 56861,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 57149,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 57317,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 57405,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 78,
      "text": "n"
    },
    {
      "time": 57829,
      "type": "mistake",
      "shift": false,
      "alt": false,
      "keyCode": 49,
      "fixQueuePos": 1,
      "expectedText": " ",
      "text": "1"
    },
    {
      "time": 58069,
      "type": "backspace",
      "shift": false,
      "alt": false,
      "keyCode": 8,
      "fixQueuePos": 0
    },
    {
      "time": 58197,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 58302,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 49,
      "text": "1"
    },
    {
      "time": 58653,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 186,
      "text": ":"
    },
    {
      "time": 58973,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 78,
      "text": "n"
    },
    {
      "time": 59093,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 85,
      "text": "u"
    },
    {
      "time": 59325,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 77,
      "text": "m"
    },
    {
      "time": 60222,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 48,
      "text": ")"
    },
    {
      "time": 60454,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 61294,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 219,
      "text": "{"
    },
    {
      "time": 61606,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 13
    },
    {
      "time": 62070,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 70,
      "text": "f"
    },
    {
      "time": 62158,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 65,
      "text": "a"
    },
    {
      "time": 62270,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 67,
      "text": "c"
    },
    {
      "time": 62478,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 84,
      "text": "t"
    },
    {
      "time": 62542,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 79,
      "text": "o"
    },
    {
      "time": 62670,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 62758,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 62926,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 65,
      "text": "a"
    },
    {
      "time": 63045,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 76,
      "text": "l"
    },
    {
      "time": 63230,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 63334,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 187,
      "text": "="
    },
    {
      "time": 63486,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 63731,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 70,
      "text": "f"
    },
    {
      "time": 63794,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 65,
      "text": "a"
    },
    {
      "time": 63898,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 67,
      "text": "c"
    },
    {
      "time": 64137,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 84,
      "text": "t"
    },
    {
      "time": 64190,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 79,
      "text": "o"
    },
    {
      "time": 64334,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 64454,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 64609,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 65,
      "text": "a"
    },
    {
      "time": 64726,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 76,
      "text": "l"
    },
    {
      "time": 65710,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 66072,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 56,
      "text": "*"
    },
    {
      "time": 66775,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 32,
      "text": " "
    },
    {
      "time": 66878,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 67191,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 13
    },
    {
      "time": 68007,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 221,
      "text": "}"
    },
    {
      "time": 68359,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 13
    },
    {
      "time": 68895,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 80,
      "text": "p"
    },
    {
      "time": 69031,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 69111,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 69231,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 78,
      "text": "n"
    },
    {
      "time": 69383,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 84,
      "text": "t"
    },
    {
      "time": 69719,
      "type": "mistake",
      "shift": true,
      "alt": false,
      "keyCode": 56,
      "fixQueuePos": 1,
      "expectedText": "(",
      "text": "*"
    },
    {
      "time": 70487,
      "type": "backspace",
      "shift": false,
      "alt": false,
      "keyCode": 8,
      "fixQueuePos": 0
    },
    {
      "time": 71127,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 57,
      "text": "("
    },
    {
      "time": 72127,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 80,
      "text": "p"
    },
    {
      "time": 72247,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 65,
      "text": "a"
    },
    {
      "time": 72295,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 83,
      "text": "s"
    },
    {
      "time": 72479,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 84,
      "text": "t"
    },
    {
      "time": 72543,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 69,
      "text": "e"
    },
    {
      "time": 73399,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 57,
      "text": "("
    },
    {
      "time": 73767,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 70,
      "text": "f"
    },
    {
      "time": 73847,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 65,
      "text": "a"
    },
    {
      "time": 73983,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 67,
      "text": "c"
    },
    {
      "time": 74175,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 84,
      "text": "t"
    },
    {
      "time": 74255,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 79,
      "text": "o"
    },
    {
      "time": 74383,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 82,
      "text": "r"
    },
    {
      "time": 74488,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 73,
      "text": "i"
    },
    {
      "time": 74616,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 65,
      "text": "a"
    },
    {
      "time": 74751,
      "type": "correct",
      "shift": false,
      "alt": false,
      "keyCode": 76,
      "text": "l"
    },
    {
      "time": 75376,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 48,
      "text": ")"
    },
    {
      "time": 75528,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 48,
      "text": ")"
    },
    {
      "time": 76080,
      "type": "correct",
      "shift": true,
      "alt": false,
      "keyCode": 221,
      "text": "}"
    }
  ],
  "cheat": false,
  "firstCharTime": 1597688868017,
  "earlyFinish": false,
  "startTime": 1597688867022,
  "oneThirdCharsCount": 103,
  "oneThirdTime": 34888,
  "lastThirdCharsCount": 53,
  "lastThirdStartTime": 61622,
  "timeFromFirstInput": 76782,
  "codeLength": 216,
  "file": {
    "languageName": 'R',
    "languageIndex": 20,
    "index": 0,
    "name": "factorial_of_a_number",
    "source": "datamentor.io",
    "tabSize": 2,
    "lines": 12
  }
});
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/CodeEditor.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* eslint-disable no-tabs */




// import { loadMode, loadTheme } from '@/cmLoader';

// import { codemirror } from 'vue-codemirror';
// import codemirror from 'vue-codemirror/src/codemirror.vue';


// const { codemirror } = () => import(/* webpackChunkName: "vueCodeMirror" */ 'vue-codemirror');
// import 'codemirror/addon/edit/closebrackets';
// import 'codemirror/addon/selection/active-line';

// const codemirror = () => import(/* webpackChunkName: "vueCodeMirror" */ 'vue-codemirror').then((module) => ({ default: module.codemirror }));
// const codemirror2 = () => import(/* webpackChunkName: "vueCodeMirror" */ 'vue-codemirror');
let loadMode; let
  loadTheme;
const codemirror = () => __webpack_require__.e(/* import() | cmLoader */ "cmLoader").then(__webpack_require__.bind(null, "a0ca")).then((module) => {
  loadMode = module.loadMode;
  loadTheme = module.loadTheme;
  return module.default;
});


/* harmony default export */ var CodeEditorvue_type_script_lang_js_ = ({
  components: {
    codemirror,
  },
  data() {
    return {
      timeout: 0,
      countdown: 3,
      showPopUp: true,
      popUpClickable: false,
      popUpText: '3',
      cm: {},
      codeText: '',
      started: false,
      isCompleted: false,
      cmReady: false,
      toFix: 0,
      rightMostMistakeMarked: false,
      markers: [],
      currentLine: 0,
      currentChar: 0,
      correctCharsInLine: 0,
      currentChange: {},
      stats: {
        history: [],
        cheat: false,
        firstCharTime: 0,
        earlyFinish: false,
      },
    };
  },
  computed: {
    ...Object(vuex_esm["b" /* mapGetters */])(['language', 'options', 'codeInfo', 'customCode', 'room']),
    cmOptions() {
      return {
        showInvisibles: this.language.name === 'Whitespace',
        maxInvisibles: 2,
        undoDepth: 0,
        tabSize: this.tabWidth,
        styleActiveLine: false,
        lineNumbers: this.options.lineNumbers,
        styleSelectedText: true,
        lineWrapping: true,
        matchBrackets: false,
        dragDrop: false,
        autoCloseBrackets: false,
        cursorBlinkRate: 320,
        smartIndent: false,
        lint: false,
        spellcheck: false,
        autocorrect: false,
        showCursorWhenSelecting: true,
        theme: this.options.selectedTheme,
        cursorScrollMargin: 100,
        readOnly: true,
      };
    },
    tabWidth() {
      return this.customCode.tabSize ? this.customCode.tabSize : this.codeInfo.tabSize;
    },
  },
  methods: {
    popUp(action, text = this.popUpText) {
      console.log('POPUP ', action);
      this.popUpText = text;

      if (action) {
        if (text === 'Resume') {
          this.popUpClickable = true;
        }
      } else {
        this.popUpClickable = false;
        this.cm.focus();
      }
      this.showPopUp = action;
    },
    onCmReady(cm) {
      this.cm = cm;

      this.init(); // TODO
      this.fixHeight();

      // cm.setOption('readOnly', true);
    },
    onKeyDown(ev) {
      console.log(ev);
      // const allowedKeys = 'qwertyuiopasdfghjklzxcvbnm1234567890!@#$%^&*()-=_+[]{};\'\\:"|,./<>?`~';

      const handleEnter = () => {
        const expectedText = this.cm.getLine(this.currentLine);
        // console.green(expectedText);
        if (this.correctCharsInLine === expectedText.length) {
          this.cm.execCommand('goCharRight');
          this.currentLine += 1;
          console.warn(this.currentLine);

          this.currentChange = {
            ...this.currentChange,
            type: 'correct',
            text: 'Enter',
          };

          if (!this.stats.oneThirdTime && this.currentLine === Math.floor(this.codeInfo.lines / 3)) {
            console.green('one third');
            const oneThirdText = this.cm.getRange(
              { line: 0, ch: 0 },
              { line: this.currentLine, ch: 0 },
            );
            console.blue(oneThirdText);

            this.stats.oneThirdCharsCount = oneThirdText.length;
            this.stats.oneThirdTime = this.timeElapsed();
          } else if (!this.stats.lastThirdStartTime && this.currentLine === Math.floor(this.codeInfo.lines / 3 * 2)) {
            const lastThirdText = this.cm.getRange(
              { line: this.currentLine, ch: 0 },
              { line: this.codeInfo.lines + 1, ch: 0 },
            );
            console.blue(lastThirdText);
            this.stats.lastThirdCharsCount = lastThirdText.length;
            this.stats.lastThirdStartTime = this.timeElapsed();
          }

          if (this.options.autoIndent) {
            this.cm.execCommand('goLineStartSmart');
            this.currentChar = this.cm.getCursor().ch;
            this.correctCharsInLine = this.currentChar;
          } else {
            this.currentChar = 0;
            this.correctCharsInLine = 0;
          }
          if (this.options.underScore) {
            let underScoreWidth = 1;
            if (!this.options.autoIndent && this.cm.getLine(this.currentLine).slice(0, this.tabWidth) === Array(this.tabWidth).fill(' ').join('')) {
              underScoreWidth = this.tabWidth;
            }
            this.cm.markText(
              { line: this.currentLine, ch: this.currentChar },
              { line: this.currentLine, ch: this.currentChar + underScoreWidth },
              {
                className: 'next-char', clearOnEnter: true, inclusiveRight: true,
              },
            );
          }
        } else {
          console.error('enter blocked before end of the line');
          this.currentChange = {
            ...this.currentChange,
            type: 'blockedEnter',
          };
        }
      };

      const handleWrite = (key) => {
        const lineText = this.cm.getLine(this.currentLine);
        console.log(`${lineText}1`);
        if (this.currentChar !== lineText.length) { // block too long lines
          let expectedText = lineText[this.currentChar];
          console.blue(`expected: '${expectedText}'`);

          let text = key;

          if (key === 'Tab') {
            text = Array(this.tabWidth).fill(' ').join('');
            console.green(`tabText: '${text}'`);


            if (expectedText === ' ' && this.language.name !== 'Whitespace') {
              console.red(`test: '${lineText.slice(this.currentChart, this.currentChar + this.tabWidth)}'`);
              if (lineText.slice(this.currentChar, this.currentChar + this.tabWidth) === text) {
                console.log('if');
                expectedText = text;
                console.red(`expectedText: '${text}'`);
              }
            } else if (expectedText === '	') { // Tab character
              text = '	';
            }
          }
          console.green(`text: '${text}'`);
          if (text === expectedText) {
            if (this.toFix) {
              console.red(`blocked unfixed mistakes: ${this.toFix}`);
              this.currentChange = {
                ...this.currentChange,
                type: 'unfixed',
                text,
              };
            } else {
              this.cm.markText(
                { line: this.currentLine, ch: this.currentChar },
                { line: this.currentLine, ch: this.currentChar + text.length },
                { className: 'correct' },
              );


              this.currentChar += text.length;
              this.correctCharsInLine += text.length;

              this.currentChange = {
                ...this.currentChange,
                type: 'correct',
                text,
              };

              if (text.length > 1) {
                this.cm.startOperation();
                for (let i = 0; i < text.length; i += 1) {
                  this.cm.execCommand('goCharRight');
                }
                this.cm.endOperation();
              } else {
                this.cm.execCommand('goCharRight');
              }



              if (this.currentLine + 1 === this.codeInfo.lines && this.correctCharsInLine === this.cm.getLine(this.currentLine).length) {
                this.completed();
              } else if (this.options.underScore) {
                if (this.currentChar !== lineText.length) {
                  let underScoreWidth = 1;
                  if (!this.options.autoIndent && this.cm.getLine(this.currentLine).slice(this.currentChar, this.tabWidth + this.currentChar) === Array(this.tabWidth).fill(' ').join('')) {
                    underScoreWidth = this.tabWidth;
                  }
                  this.cm.markText(
                    { line: this.currentLine, ch: this.currentChar },
                    { line: this.currentLine, ch: this.currentChar + underScoreWidth },
                    { className: 'next-char', clearOnEnter: true, inclusiveRight: true },
                  );
                } else {
                  // it can confuse the player
                  // const char = this.cm.getLine(this.currentLine + 1).match('[^\\S]*')[0].length;
                  // this.cm.markText(
                  //   { line: this.currentLine + 1, ch: char },
                  //   { line: this.currentLine + 1, ch: char + 1 },
                  //   { className: 'next-char', clearOnEnter: true, inclusiveRight: true },
                  // );
                }
              }
            }
          } else {
            this.toFix += 1;
            console.red(`wrong: ${this.toFix}`);
            const marker = this.cm.markText(
              { line: this.currentLine, ch: this.currentChar },
              { line: this.currentLine, ch: this.currentChar + text.length },
              { className: 'mistake' },
            );
            // TODO show missclicked char
            this.markers.push(marker);
            this.currentChar += text.length;
            this.currentChange = {
              ...this.currentChange,
              type: 'mistake',
              fixQueuePos: this.toFix,
              expectedText,
              text,
            };

            if (text.length > 1) {
              this.cm.startOperation();
              for (let i = 0; i < text.length; i += 1) {
                this.cm.execCommand('goCharRight');
              }
              this.cm.endOperation();
            } else {
              this.cm.execCommand('goCharRight');
            }
          }
        } else {
          this.currentChange = {
            ...this.currentChange,
            type: 'lineEnd',
          };
          console.red('overshoot');
        }
      };

      if (ev.key === 'Shift' || ev.key === 'CapsLock' || ev.key === 'Alt' || ev.key === 'PageUp' || ev.key === 'PageDown' || ev.key === 'ScrollLock' || ev.ctrlKey || ev.metaKey || ev.key.slice(0, 5) === 'Arrow' || (ev.key.length > 1 && ev.key[0] === 'F')) {
        // prevent double event and block keys
        return;
      }
      if (this.started && !this.stats.firstCharTime) {
        this.stats.firstCharTime = Date.now();
      }
      this.currentChange = {
        time: this.timeElapsed(),
        type: 'initialType',
        shift: ev.shiftKey,
        alt: ev.altKey,
        keyCode: ev.keyCode,
      };



      if (ev.key === 'Escape' || ev.key === 'Pause') {
        this.popUp(true, 'Resume');
      } else if (ev.key === 'Insert') {
        this.cm.execCommand('goLineEnd');
        this.cm.execCommand('goCharRight');
        this.cm.markText(
          { line: this.currentLine, ch: this.currentChar },
          { line: this.currentLine, ch: this.cm.getLine(this.currentLine).length + 1 },
          { className: 'correct' },
        );
        this.currentLine += 1;
        this.currentChar = 0;
        this.correctCharsInLine = 0;
        this.stats.cheat = true;
      } else if (ev.key === 'End') {
        this.stats.cheat = true;
        this.completed(true);
      } else if (ev.key === 'Home') {
        this.cm.execCommand('goDocEnd');
        this.cm.markText(
          { line: 0, ch: 0 },
          { line: this.codeInfo.lines + 1, ch: 1 },
          { className: 'correct' },
        );
        this.currentLine = this.codeInfo.lines - 1;
        this.currentChar = this.cm.getLine(this.currentLine);
        this.correctCharsInLine = this.currentChar;
        this.stats.cheat = true;
        this.completed(false, false);
      } else if (ev.key === 'Enter') {
        handleEnter();
      } else if (ev.key === 'Backspace') {
        if (this.toFix) {
          this.toFix -= 1;

          // this.cm.execCommand('undo'); // clear marker
          const marker = this.markers.pop();
          console.log(marker);
          const position = marker.find();
          console.log(position);
          marker.clear();

          const markerLength = position.to.ch - position.from.ch;
          if (markerLength > 1) {
            this.cm.startOperation();
            for (let i = 0; i < markerLength; i += 1) {
              this.cm.execCommand('goCharLeft');
            }
            this.cm.endOperation();
          } else {
            this.cm.execCommand('goCharLeft');
          }

          console.blue(`markerLength: ${markerLength}`);

          this.currentChar -= markerLength;
          this.currentChange = {
            ...this.currentChange,
            type: 'backspace',
            fixQueuePos: this.toFix,
          };
          console.blue(`Deleted tofix: ${this.toFix}`);
          if (this.toFix > 0) {
            console.blue('TOFIX > 0');
            if (this.rightMostMistakeMarked) {
              console.blue('middle');
              this.cm.markText(position.from, position.to, { className: 'corrected middle' });
            } else {
              console.blue('rightMost');
              this.cm.markText(position.from, position.to, { className: 'corrected right-most' });
              this.rightMostMistakeMarked = true;
            }
          } else {
            console.green(`TOFIX = 0 ${position.from.ch} ${position.to.ch}`);

            if (this.rightMostMistakeMarked) {
              console.blue('left-most');
              this.rightMostMistakeMarked = false;
              this.cm.markText(position.from, position.to, { className: 'corrected left-most' });
            } else {
              console.blue('alone');

              this.cm.markText(position.from, position.to, { className: 'corrected alone' });
            }



            if (this.options.underScore) {
              let underScoreWidth = 1;
              if (!this.options.autoIndent && this.cm.getLine(this.currentLine).slice(this.currentChar, this.tabWidth + this.currentChar) === Array(this.tabWidth).fill(' ').join('')) {
                underScoreWidth = this.tabWidth;
              }
              this.cm.markText(
                { line: this.currentLine, ch: this.currentChar },
                { line: this.currentLine, ch: this.currentChar + underScoreWidth },
                { className: 'next-char', clearOnEnter: true, inclusiveRight: true },
              );
            }
          }
        } else {
          console.blue('Blocked Nothing to fix');
          this.currentChange = {
            ...this.currentChange,
            type: 'blockedBackspace',
          };
        }
      // } else if (ev.key === 'Tab') {
        // eslint-disable-next-line no-tabs
        // handleWrite('	', ev);
        // for (let i = 0; i < this.tabWidth; i += 1) {
        //   this.cm.startOperation();
        //   handleWrite(' ', ev);
        //   this.cm.endOperation();
        // }
      } else {
        handleWrite(ev.key, ev);
      }

      if (this.currentChange.type !== 'initialType') {
        this.stats.history.push(this.currentChange);
      }
      this.currentChange = {};
    },
    onUnFocus(_, ev) {
      // ev.preventDefault(); // DEV
      // console.red('blur');
      if (!this.isCompleted && ev) {
        // this.cm.focus(); // DEV
        if (ev.relatedTarget !== null) {
          if (ev.relatedTarget.tagName !== 'BUTTON' && ev.relatedTarget.tagName !== 'A') {
            this.popUp(true, 'Resume'); // dev
          } else if (ev.relatedTarget.className === 'disconnect-btn') {
            this.cm.focus();
          }
        } else {
          this.popUp(true, 'Resume');
        }
      }
    },
    fixHeight() {
      const height = `${this.$refs.container.offsetHeight}px`;
      // console.blue(`height: ${height}`);
      const scroll = this.$refs.codemirror.$el.getElementsByClassName('CodeMirror-scroll')[0];
      scroll.style.maxHeight = height;
    },
    async getCode() {
      if (!this.codeInfo.name) {
        return this.customCode.text;
      }
      const url = `${"https://coderushcdn.ddns.net" || false}/code/${this.language.name.replace('#', '_sharp')}/${this.codeInfo.name}.${this.language.ext}`;
      try {
        const resp = await axios_default.a.get(url);
        return resp.data;
      } catch (err) {
        if (err.request) {
          throw new Error('No internet');
        } else {
          throw err;
        }
      }
    },
    timeElapsed() {
      return Date.now() - this.stats.firstCharTime;
    },
    start(interval) {
      clearInterval(interval);
      this.cm.markText(
        { line: 0, ch: 0 },
        { line: this.codeInfo.lines + 1, ch: 1 },
        { className: 'bugfix' },
      );
      if (this.options.underScore) {
        this.cm.markText(
          { line: this.currentLine, ch: this.currentChar },
          { line: this.currentLine, ch: this.currentChar + 1 },
          { className: 'next-char', clearOnEnter: true, inclusiveRight: true },
        );
      }
      this.popUp(false, 'WRITE');
      this.started = true;
      this.cm.focus();
      console.log('START');
      this.stats.startTime = Date.now();
    },
    init() {
      const initTime = Date.now();
      const interval = setInterval(() => {
        this.countdown -= 0.5;
        this.popUpText = Math.ceil(this.countdown);
        if (this.countdown === 2) {
          if (!this.cmReady || !this.codeText) {
            this.countdown += 0.5;
            console.warn(Date.now() - initTime);
            if ((Date.now() - initTime) / 1000 < 5) {
              this.popUpText = 'Waiting for download...';
            } else {
              console.warn('Long loading time');
              this.popUpText = 'Something propably crashed but you can wait a few seconds just in case';
            }
          }
        } else if (this.countdown === 0) {
          this.start(interval);
        }
      }, 500); // DEV 500


      // console.log('loadMode ', Date.now());

      Promise.all([this.getCode(), loadTheme(this.options.selectedTheme), loadMode(this.cm, this.language.mode)])
        .then((resp) => {
        // console.log(resp);
          [this.codeText] = resp;
          this.cmReady = true;
        })
        .catch((err) => {
          clearInterval(interval);
          console.log(err);
          if (err.message === 'No internet') {
            this.popUpText = 'Connection with server not available.';
          } else {
            this.popUpText = 'Please try again later';
          }
        });
    },
    completed(forced = false, currentStats = true) {
      if (this.$route.path === '/results' || (forced && this.stats.history.length < 10)) {
        // return; DEV
      }
      this.cm.setOption('readOnly', 'nocursor');
      this.popUp(true, forced ? 'Too long, uh?' : 'Congratulations');
      if (this.room.connected) {
        this.$socket.client.emit('completed', Date.now());
      }

      if (currentStats) {
        this.stats = {
          ...this.stats,
          timeFromFirstInput: this.timeElapsed(),
          codeLength: this.codeText.length,
          file: this.codeInfo,
        };
        if (forced) {
          this.stats.earlyFinish = true;
        }
      } else {
        this.stats = stats2;
      }

      console.log(JSON.parse(JSON.stringify(this.stats)));

      this.$emit('completed', this.stats);
      this.isCompleted = true;
      setTimeout(() => {
        this.$router.replace('/results');
        this.popUp(false);
      }, 2000); // DEV 2000
    },
  },
});

// CONCATENATED MODULE: ./src/components/CodeEditor.vue?vue&type=script&lang=js&
 /* harmony default export */ var components_CodeEditorvue_type_script_lang_js_ = (CodeEditorvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/components/CodeEditor.vue?vue&type=style&index=0&id=a9580c94&lang=sass&scoped=true&
var CodeEditorvue_type_style_index_0_id_a9580c94_lang_sass_scoped_true_ = __webpack_require__("07fb");

// CONCATENATED MODULE: ./src/components/CodeEditor.vue






/* normalize component */

var CodeEditor_component = Object(componentNormalizer["a" /* default */])(
  components_CodeEditorvue_type_script_lang_js_,
  CodeEditorvue_type_template_id_a9580c94_scoped_true_render,
  CodeEditorvue_type_template_id_a9580c94_scoped_true_staticRenderFns,
  false,
  null,
  "a9580c94",
  null
  
)

/* harmony default export */ var CodeEditor = (CodeEditor_component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/Run.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



// const CodeEditor = () => import(/* webpackChunkName: "codeEditor" */ '@/components/CodeEditor.vue');


const Results = () => __webpack_require__.e(/* import() | results */ "results").then(__webpack_require__.bind(null, "b3c3"));

/* harmony default export */ var Runvue_type_script_lang_js_ = ({
  name: 'Run',
  components: {
    CodeEditor: CodeEditor,
    Results,
  },
  data() {
    return {
      resetSelfKey: 1,
      resetEditorKey: 1,
      stats: false,
      requestReset: false,

    };
  },
  computed: {
    ...Object(vuex_esm["b" /* mapGetters */])(['language', 'customCode', 'codeInfo', 'room']),
    codeSource() {
      if (this.codeInfo.name) {
        return this.codeInfo.source === 'own' ? 'Łukasz Wielgus archive' : this.codeInfo.source;
      } if (this.room.connected && !this.room.owner) {
        return 'Code provided by room owner';
      }
      return 'Code provided by You';
    },
    languageName() {
      return this.language.name.replace('_', ' ');
    },

  },
  created() {
    if (!this.language.name) {
      this.$router.push('/');
    }
  },
  beforeRouteUpdate(to, from, next) {
    if (to.path === '/results') {
      console.green('scroll');
      setTimeout(() => {
        this.$refs.results.scrollIntoView({
          block: 'start',
          inline: 'nearest',
          behavior: 'smooth',
        });
      }, 100);
    }

    next();
  },
  sockets: {
    reset() {
      this.requestReset = true;
    },
  },
  methods: {
    reset() {
      this.stats = false;
      this.resetEditorKey += 1;

      if (this.$route.path === '/results') {
        this.$router.push('/run');
      }
    },
    resetSelf() {
      this.resetSelfKey += 1;
      if (this.$route.path === '/results') {
        this.$router.push('/run');
      }
    },
    finish() {
      this.$refs.codeEditor.completed(true);
    },
    completed(stats) {
      this.stats = stats;
    },
    disconnect() {
      this.requestReset = false;
      this.$socket.client.disconnect();
      this.$store.commit('SET_ROOM_PROPERTY', ['connected', false]);
    },
  },
});


// CONCATENATED MODULE: ./src/views/Run.vue?vue&type=script&lang=js&
 /* harmony default export */ var views_Runvue_type_script_lang_js_ = (Runvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/views/Run.vue?vue&type=style&index=0&id=0f118d76&lang=sass&scoped=true&
var Runvue_type_style_index_0_id_0f118d76_lang_sass_scoped_true_ = __webpack_require__("692f");

// CONCATENATED MODULE: ./src/views/Run.vue






/* normalize component */

var Run_component = Object(componentNormalizer["a" /* default */])(
  views_Runvue_type_script_lang_js_,
  Runvue_type_template_id_0f118d76_scoped_true_render,
  Runvue_type_template_id_0f118d76_scoped_true_staticRenderFns,
  false,
  null,
  "0f118d76",
  null
  
)

/* harmony default export */ var Run = (Run_component.exports);
// CONCATENATED MODULE: ./src/router/index.js






const About = () => __webpack_require__.e(/* import() | about */ "about").then(__webpack_require__.bind(null, "f820"));
const Contribute = () => __webpack_require__.e(/* import() | contribute */ "contribute").then(__webpack_require__.bind(null, "61d5"));

vue_runtime_esm["a" /* default */].use(vue_router_esm["a" /* default */]);

const routes = [
  {
    path: '/',
    name: 'Start',
    component: Start,
  },
  {
    path: '/about',
    name: 'About',
    component: About,
  },
  {
    path: '/run',
    name: 'Run',
    component: Run,
    alias: '/results',
  },
  {
    path: '/contribute',
    name: 'Contribute',
    component: Contribute,
  },
  {
    path: '/join/:roomName',
    component: Start,
  },
  {
    path: '*',
    component: PageNotFound,
  },
];

const router = new vue_router_esm["a" /* default */]({
  mode: 'history',
  routes,
});

/* harmony default export */ var src_router = (router);

// CONCATENATED MODULE: ./src/store/modules/options.js


const options_state = {
  userLanguage: false,
  language: {
    index: null,
  },
  options: {
    codeLength: false,
    lineNumbers: true,
    selectedTheme: 'material-darker',
    selectedMode: 1,
    autoIndent: true,
    underScore: true,
    mode: 1,
  },
};

const getters = {
  userLanguage: (state) => state.userLanguage,
  language: (state) => state.language,
  options: (state) => state.options,
  getLanguage: (state) => Object(index_esm["b" /* getField */])(state),
  getOption: (state) => Object(index_esm["b" /* getField */])(state.options),
};

const actions = {};

const mutations = {
  USER_LANGUAGE: (state) => {
    state.userLanguage = !state.userLanguage;
  },
  SET_LANGUAGE: (state, languageObj) => {
    state.language = languageObj;
  },
  SET_OPTION: (state, { name, value }) => {
    state.options[name] = value;
  },
  UPDATE_LANGUAGE(state, language) {
    Object(index_esm["c" /* updateField */])(state, language);
  },
  UPDATE_OPTION(state, option) {
    Object(index_esm["c" /* updateField */])(state.options, option);
  },

};

/* harmony default export */ var options = ({
  state: options_state,
  getters,
  actions,
  mutations,
});

// CONCATENATED MODULE: ./src/store/modules/room.js


const room_state = {
  room: {
    connected: false,
    name: '',
    players: {},
    myName: '',
    owner: false,
  },
};

const room_getters = {
  room: (state) => state.room,
  players: (state) => state.room.players,
};

const room_actions = {
  socket_playerDisconnected({ commit }, msg) {
    if (msg.owner) {
      commit('SET_ROOM_PROPERTY', ['connected', false]);
      console.log(this);
      this._vm.$socket.client.disconnect();
    }

    commit('PLAYER_LOST_CONNECTION', {
      playerName: msg.playerName,
      currentState: 'lostConnection',
    });
    setTimeout(() => {
      commit('PLAYER_LOST_CONNECTION', {
        playerName: msg.playerName,
        currentState: 'disconnected',
      });
    }, 5000);
  },
  socket_roomState({ commit }, roomState) {
    commit('SET_ROOM_PROPERTY', ['name', roomState.roomName]);
    commit('SET_ROOM_PROPERTY', ['connected', true]);
    const playersObject = {};
    roomState.players.forEach(({
      name, ready, connected, owner,
    }) => {
      playersObject[name] = { ready, connected, owner };
    });
    commit('SET_ROOM_PROPERTY', ['players', playersObject]);
    Object.entries(roomState.options).forEach((option) => {
      commit('SET_OPTION', option);
    });
  },
  socket_optionChange({ commit }, option) {
    commit('SET_OPTION', option);
  },
  socket_languageChange({ commit, rootState }, languageIndex) {
    commit('SET_LANGUAGE', rootState.other.languagesList[languageIndex]);
  },
  socket_fileIndex({ dispatch }, fileIndex) {
    dispatch('generateCodeInfo', fileIndex);
  },
  socket_customCodeData({ commit }, data) {
    commit('SET_CUSTOM_CODE', data);
  },
  socket_useCustomCode({ commit }, message) {
    commit('USE_CUSTOM_CODE', message);
  },
  socket_reset({ commit, state }) {
    Object.keys(state.room.players).forEach((playerName) => {
      commit('RESET_PLAYER', playerName);
    });
  },
};

const room_mutations = {
  SOCKET_PLAYER_STATE_CHANGE(state, message) {
    vue_runtime_esm["a" /* default */].set(state.room.players[message.playerName], 'ready', message.currentState);
  },
  SOCKET_PLAYER_JOINED(state, playerName) {
    console.log('JOIN');
    // Vue reactivity caveat
    vue_runtime_esm["a" /* default */].set(state.room.players, playerName, {
      ready: false,
      connected: true,
    });
  },
  SOCKET_PLAYER_COMPLETED(state, message) {
    vue_runtime_esm["a" /* default */].set(state.room.players[message.playerName], 'completed', true);
    vue_runtime_esm["a" /* default */].set(state.room.players[message.playerName], 'time', message.time);
  },
  SOCKET_PLAYER_STATS(state, message) {
    vue_runtime_esm["a" /* default */].set(state.room.players[message.playerName], 'stats', message.stats);
  },
  PLAYER_LOST_CONNECTION(state, { playerName, currentState }) {
    if (currentState === 'lostConnection') {
      vue_runtime_esm["a" /* default */].set(state.room.players[playerName], 'connected', false);
    } else {
      vue_runtime_esm["a" /* default */].delete(state.room.players, playerName);
    }
  },
  RESET_PLAYER(state, playerName) {
    vue_runtime_esm["a" /* default */].delete(state.room.players[playerName], 'stats');
    vue_runtime_esm["a" /* default */].delete(state.room.players[playerName], 'completed');
    vue_runtime_esm["a" /* default */].delete(state.room.players[playerName], 'time');
  },
  LATENCY(state, ownerStartTime) {
    state.room.ownerStartTime = ownerStartTime;
  },
  SET_ROOM_PROPERTY(state, [property, value]) {
    console.log(property, value);
    vue_runtime_esm["a" /* default */].set(state.room, property, value);
  },

};

/* harmony default export */ var room = ({
  state: room_state,
  getters: room_getters,
  actions: room_actions,
  mutations: room_mutations,
});

// CONCATENATED MODULE: ./src/store/modules/other.js



const other_state = {
  languagesList: [],
  customCode: {
    text: '',
    tabSize: 0,
    lines: 0,
    showEditor: false,
  },
  codeInfo: {},
  trackedContainers: [],
};

const other_getters = {
  languagesList: (state) => state.languagesList,
  customCode: (state) => state.customCode,
  codeInfo: (state) => state.codeInfo,
  trackedContainers: (state) => state.trackedContainers,
};

const other_actions = {
  loadLanguagesList: async (context) => {
    if (!context.state.languagesList.length) {
      try {
        const response = await axios_default.a.get('/database.json');
        const languagesList = response.data.languages.map((language, index) => ({ ...language, index }));
        context.commit('SET_LANGUAGES_LIST', languagesList);
      } catch (err) {
        console.warn('LANGUAGE LIST ERROR', err);
      }
    }
  },
  deleteCustomCode: (context) => {
    context.commit('SET_CUSTOM_CODE', {
      text: '', tabSize: 0, lines: 0, showEditor: false,
    });
  },
  generateCodeInfo: ({ state, rootState, commit }, fileIndex) => {
    let codeInfo = {};
    if (fileIndex === -1) {
      codeInfo.tabSize = state.customCode.lines;
      codeInfo.lines = state.customCode.lines;
    } else {
      codeInfo = rootState.options.language.files[fileIndex];
    }
    codeInfo.index = fileIndex;
    codeInfo.languageIndex = rootState.options.language.index;
    codeInfo.languageName = rootState.options.language.name;

    commit('SET_CODE_INFO', codeInfo);
  },
};

const other_mutations = {
  SET_LANGUAGES_LIST: (state, list) => {
    state.languagesList = list;
  },
  SET_CUSTOM_CODE: (state, code) => {
    state.customCode = code;
  },
  USE_CUSTOM_CODE: (state, message) => {
    console.log('use custom code');
    vue_runtime_esm["a" /* default */].set(state.customCode, 'showEditor', message);
  },
  SET_CODE_INFO(state, codeInfo) {
    state.codeInfo = codeInfo;
  },
  ADD_TRACKED_CONTAINER(state, container) {
    state.trackedContainers.push(container);
  },
  REMOVE_TRACKED_CONTAINER(state, className) {
    const index = state.trackedContainers.findIndex((el) => el.className === className);
    if (index !== -1) {
      state.trackedContainers.splice(index, 1);
    }
  },
};

/* harmony default export */ var other = ({
  state: other_state,
  getters: other_getters,
  actions: other_actions,
  mutations: other_mutations,
});

// CONCATENATED MODULE: ./src/store/index.js






vue_runtime_esm["a" /* default */].use(vuex_esm["a" /* default */]);

/* harmony default export */ var store = (new vuex_esm["a" /* default */].Store({
  modules: {
    options: options,
    room: room,
    other: other,
  },

}));

// CONCATENATED MODULE: ./src/main.js







// import { fab } from '@fortawesome/free-brands-svg-icons';
// import { far } from '@fortawesome/free-regular-svg-icons';



// import trackMouse from './trackMouse';

// Vue.mixin(trackMouse);

const socket = lib_default()('/', {
  autoConnect: false,
  reconnectionAttempts: 3,
  timeout: 10000,
});

index_es["c" /* library */].add(free_solid_svg_icons_index_es["l" /* faUsers */], free_solid_svg_icons_index_es["g" /* faPlay */], free_solid_svg_icons_index_es["c" /* faGlobeAmericas */], free_solid_svg_icons_index_es["d" /* faGlobeEurope */], free_solid_svg_icons_index_es["f" /* faInfo */], free_solid_svg_icons_index_es["b" /* faFileCode */], free_solid_svg_icons_index_es["e" /* faHeart */], free_solid_svg_icons_index_es["h" /* faServer */], free_solid_svg_icons_index_es["k" /* faUser */], free_solid_svg_icons_index_es["j" /* faSignOutAlt */], free_solid_svg_icons_index_es["a" /* faCopy */], free_solid_svg_icons_index_es["i" /* faShareAlt */]);

vue_runtime_esm["a" /* default */].use(vue_socket_io_ext_esm["a" /* default */], socket, { store: store });
vue_runtime_esm["a" /* default */].component('fa', vue_fontawesome_index_es["a" /* FontAwesomeIcon */]);
vue_runtime_esm["a" /* default */].config.productionTip = false;

new vue_runtime_esm["a" /* default */]({
  router: src_router,
  store: store,
  render(h) { return h(App); },
}).$mount('#app');

window.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'webpackInvalid') {
    console.clear();
  }
});

console.red = (msg) => {
  console.log(`%c${msg}`, 'color: #f44336');
};
console.green = (msg) => {
  console.log(`%c${msg}`, 'color: #00dd00');
};
console.blue = (msg) => {
  console.log(`%c${msg}`, 'color: #00cdff');
};



/***/ }),

/***/ "61dc":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavBar_vue_vue_type_style_index_0_id_7f714fa1_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("3243");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavBar_vue_vue_type_style_index_0_id_7f714fa1_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavBar_vue_vue_type_style_index_0_id_7f714fa1_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavBar_vue_vue_type_style_index_0_id_7f714fa1_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "63ca":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "692f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Run_vue_vue_type_style_index_0_id_0f118d76_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2e4a");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Run_vue_vue_type_style_index_0_id_0f118d76_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Run_vue_vue_type_style_index_0_id_0f118d76_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Run_vue_vue_type_style_index_0_id_0f118d76_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "7427":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "7447":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Start_vue_vue_type_style_index_0_id_40614b6b_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("63ca");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Start_vue_vue_type_style_index_0_id_40614b6b_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Start_vue_vue_type_style_index_0_id_40614b6b_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Start_vue_vue_type_style_index_0_id_40614b6b_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "7629":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RoomPanel_vue_vue_type_style_index_0_id_7610ead2_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("3743");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RoomPanel_vue_vue_type_style_index_0_id_7610ead2_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RoomPanel_vue_vue_type_style_index_0_id_7610ead2_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RoomPanel_vue_vue_type_style_index_0_id_7610ead2_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "8c3e":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "8d8e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"4cb10de2-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/UploadCode.vue?vue&type=template&id=9bbccf4e&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"wrapper"},[_c('div',{staticClass:"warning"},[(!_vm.language.index)?_c('span',[_vm._v(" Choose language "),_c('fa',{staticClass:"arrow",attrs:{"icon":['fas', 'play']}})],1):_vm._e()]),_c('div',{staticClass:"settings"},[(_vm.$route.path === '/contribute')?_c('div',{},[_c('label',[_vm._v("Code functionality (or product name)")]),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.name),expression:"name"}],attrs:{"type":"text"},domProps:{"value":(_vm.name)},on:{"input":function($event){if($event.target.composing){ return; }_vm.name=$event.target.value}}})]):_vm._e(),_c('div',{staticClass:"tab-settings"},[_c('span',{staticClass:"tab-text"},[_vm._v("Tab size:")]),_vm._l((_vm.tabSizes),function(size){return _c('label',{key:size,staticClass:"tab-size-option",class:{'selected': size === _vm.selectedSize}},[_c('span',[_vm._v(_vm._s(size))]),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.selectedSize),expression:"selectedSize"}],attrs:{"type":"radio"},domProps:{"value":size,"checked":_vm._q(_vm.selectedSize,size)},on:{"change":function($event){_vm.selectedSize=size}}})])})],2),_c('p',{directives:[{name:"show",rawName:"v-show",value:(_vm.language.index && !_vm.editorReady ),expression:"language.index && !editorReady "}]},[_vm._v(" Loading... ")])]),_c('codemirror',{ref:"codemirror",staticClass:"codemirror",class:{ready: _vm.editorReady},attrs:{"options":_vm.cmOptions},on:{"ready":_vm.onCmReady,"input":_vm.useCustomCode},model:{value:(_vm.code),callback:function ($$v) {_vm.code=$$v},expression:"code"}}),(_vm.$route.path === '/contribute')?_c('div',{staticClass:"buttons"},[_c('button',{on:{"click":_vm.sendCustomCode}},[_vm._v(" Send ")])]):_vm._e()],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/UploadCode.vue?vue&type=template&id=9bbccf4e&scoped=true&

// EXTERNAL MODULE: ./node_modules/vuex/dist/vuex.esm.js
var vuex_esm = __webpack_require__("2f62");

// EXTERNAL MODULE: ./node_modules/axios/index.js
var axios = __webpack_require__("bc3a");
var axios_default = /*#__PURE__*/__webpack_require__.n(axios);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/UploadCode.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



// import { loadMode, loadTheme } from '@/cmLoader';
// import { codemirror } from 'vue-codemirror';

// const { codemirror } = () => import(/* webpackChunkName: "vueCodeMirror" */ 'vue-codemirror');
// import codemirror from 'vue-codemirror/src/codemirror.vue';
// const codemirror = () => import(/* webpackChunkName: "codemirror" */ 'vue-codemirror/src/codemirror.vue');
let loadMode; let
  loadTheme;
const codemirror = () => __webpack_require__.e(/* import() | cmLoader */ "cmLoader").then(__webpack_require__.bind(null, "a0ca")).then((module) => {
  loadMode = module.loadMode;
  loadTheme = module.loadTheme;
  return module.default;
});


/* harmony default export */ var UploadCodevue_type_script_lang_js_ = ({
  name: 'UploadCode',
  components: {
    codemirror,
  },
  data() {
    return {
      code: '',
      confirmMsg: '',
      name: '',
      timeout: 0,
      editorReady: false,
      tabSizes: [2, 4, 8],
      selectedSize: 2,
    };
  },
  computed: {
    ...Object(vuex_esm["b" /* mapGetters */])(['room', 'languagesList', 'language']),
    cmOptions() {
      return {
        tabSize: this.selectedSize,
        lineNumbers: true,
        mathBrackets: true,
        styleSelectedText: true,
        styleActiveLine: false,
        lineWrapping: true,
        theme: 'material-darker',
        viewportMargin: Infinity,
      };
    },
    numberOfLines() {
      return this.code.split(/\r\n|\r|\n/).length;
    },
  },
  watch: {
    async language() {
      this.editorReady = false;
      await loadMode(this.cm, this.language.mode);
      console.green('watch');
      this.editorReady = true;
    },
  },
  mounted() {
    console.log('Activated');
    console.log(this.language.index);
    if (this.code) {
      this.useCustomCode();
    }
  },
  methods: {
    onCmReady(cm) {
      console.log('cm ready');
      this.cm = cm;
      loadTheme();
      if (this.language.name) {
        loadMode(this.cm, this.language.mode);
        this.editorReady = true;
      }
      cm.focus();
      this.fixHeight();
      window.addEventListener('resize', this.fixHeight);
    },
    fixHeight() {
      if (this.timeout) window.clearTimeout(this.timeout);
      this.timeout = window.setTimeout(() => {
        const scroll = this.$refs.codemirror.$el.getElementsByClassName('CodeMirror-scroll')[0];
        console.log(this.$refs.codemirror.$el.offsetHeight);
        scroll.style.maxHeight = `${this.$refs.codemirror.$el.offsetHeight}px`;
        scroll.style.width = `${this.$refs.codemirror.$el.offsetWidth}px`;
      }, 100);
    },
    useCustomCode() {
      if (this.timeout) clearTimeout(this.timeout);
      this.timeout = setTimeout(() => {
        this.$store.commit('SET_CUSTOM_CODE', {
          text: this.code,
          tabSize: this.selectedSize,
          lines: this.numberOfLines,
          showEditor: true,
        });
      }, 600);
    },
    sendCustomCode() {
      if (this.numberOfLines >= 5) {
        const data = {
          code: this.code,
          languageIndex: this.languageIndex,
          name: this.name ? this.name : Math.floor(Math.random() * 10000),
          ext: this.currentLanguage.ext,
          tabSize: this.selectedSize,
          numberOfLines: this.numberOfLines,
        };
        const url = `${window.location.origin}/upload`;
        axios_default.a.post(url, data)
          .then((res) => {
            console.log(res);
          })
          .catch((res) => {
            console.warn(res);
          });
      } else {
        console.log('CUSTOM CODE TOO SHORT');
        this.confirmMsg = 'Code needs to be a little bit longer.';
      }
    },
  },
});

// CONCATENATED MODULE: ./src/components/UploadCode.vue?vue&type=script&lang=js&
 /* harmony default export */ var components_UploadCodevue_type_script_lang_js_ = (UploadCodevue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/components/UploadCode.vue?vue&type=style&index=0&id=9bbccf4e&lang=sass&scoped=true&
var UploadCodevue_type_style_index_0_id_9bbccf4e_lang_sass_scoped_true_ = __webpack_require__("ab47");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/components/UploadCode.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  components_UploadCodevue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "9bbccf4e",
  null
  
)

/* harmony default export */ var UploadCode = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "941e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_LanguagesList_vue_vue_type_style_index_0_id_2b6d3ee5_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2f3e");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_LanguagesList_vue_vue_type_style_index_0_id_2b6d3ee5_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_LanguagesList_vue_vue_type_style_index_0_id_2b6d3ee5_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_LanguagesList_vue_vue_type_style_index_0_id_2b6d3ee5_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "ab47":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UploadCode_vue_vue_type_style_index_0_id_9bbccf4e_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("7427");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UploadCode_vue_vue_type_style_index_0_id_9bbccf4e_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UploadCode_vue_vue_type_style_index_0_id_9bbccf4e_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UploadCode_vue_vue_type_style_index_0_id_9bbccf4e_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "ad14":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "b341":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PlayersList_vue_vue_type_style_index_0_id_2892573a_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("3fc2");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PlayersList_vue_vue_type_style_index_0_id_2892573a_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PlayersList_vue_vue_type_style_index_0_id_2892573a_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_PlayersList_vue_vue_type_style_index_0_id_2892573a_lang_sass_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "cf25":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_style_index_0_lang_sass___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("fea6");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_style_index_0_lang_sass___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_style_index_0_lang_sass___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_0_0_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_style_index_0_lang_sass___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "fea6":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ })

/******/ });